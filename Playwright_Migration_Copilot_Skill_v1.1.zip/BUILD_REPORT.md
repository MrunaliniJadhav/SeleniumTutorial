# Copilot migration skill v1.1

Updated 22 October 2026.

## Result

Token optimization, usage alerts and model-neutral compatibility profiles are implemented. The complete current toolkit/benchmark suite passes 120 tests with no skips. This is a validated local workflow implementation, not a claim of live Copilot integration, per-model migration accuracy or customer migration targets.

The original Selenium/Playwright rules, source preservation, attachment findings and strict quality gates remain. The new release adds executable context preparation, a normalized usage ledger, terminal alert watching, three workload profiles, cache verification and three additional schemas. Installation remains the native `.github/skills/selenium-java-to-playwright-python` folder. No provider SDK, proprietary model prompt syntax, MCP service or model-specific frontmatter is required.

## Changes

| Area | Implemented behavior |
| --- | --- |
| Context preparation | Reviewed source line spans, required-contract IDs, dependency completeness gate, hash checks, output/host reserves, optional-context pruning, exact duplicate removal |
| Context cache | Content-addressed request/source/model-policy/rule hashes; stale or edited entries cannot be reused silently |
| Smaller entry | 5,188 bytes / 602 words versus 6,205 bytes / 739 words before: 16.4% fewer bytes |
| Profiles | compact 4,000 / balanced 6,000 / frontier 10,000 estimated packet input ceilings, with separate reserves and small batch/repair caps |
| Alerts | 60% WARNING, 80% CHECKPOINT, 90% STOP; separate packet, current-context and cumulative-session measures |
| Usage accounting | Per-call normalized records, replay deduplication, conflicting-ID rejection, session separation, host/estimate separation, cache/reasoning subsets not double-counted |
| Watching | Terminal JSON alerts when a trusted normalized JSONL feed updates; one-shot/offline or bounded live runs |
| Model handoff | Checkpoint contracts, interfaces, hashes, failures and next command before changing model/context |

Thresholds are workflow rules. They do not configure provider token limits, stop hidden IDE calls, enforce billing, select models, or read inaccessible host counters.

## Actual validation

`validation/benchmark-v1_1-final.json` and its adjacent JUnit XML record the full run: 120 passed. The current additions contribute 42 tests covering profile limits, exact warning boundaries, unknown telemetry, reserve accounting, missing/oversized contracts, optional pruning, source/rule/model cache invalidation, edited-cache preservation, idempotent usage, malformed counters, context versus cumulative spend, model changes, watcher behavior and CLI exits. The 78 existing migration/browser/JVM tests still pass.

`validation/token-smoke/commands-v1_1.json` records actual CLI smoke execution across all three profiles. It exercised a bounded source packet, cache repeat, warning/checkpoint/stop, idempotent replay and feed watching. Synthetic session values of 600/800/900 against a 1,000-token planning cap triggered 60/80/90% respectively. They are test fixtures, never this run's actual token usage.

An independent forward test prepared a ready compact helper packet, removed a duplicate, omitted an oversized optional log, reused the cache and blocked unreviewed dependencies. It independently observed threshold alerts and replay safety. No live model switching or actual Codex/Opus comparison was performed.

An additional smoke check caught optional context filling a balanced packet past the stop threshold despite fitting its nominal ceiling. The implementation now prunes optional fragments before the 80% checkpoint threshold; a regression prevents that avoidable stop. Required contracts are never pruned to improve a budget status.

Lint, Python compilation and JSON schema checks pass. Runtime dependencies did not change. Previous template installation/type/browser/reporting checks and attachment evidence remain under `validation/v1_0`; current benchmark evidence supersedes their test counts. Historical rule versions/checkpoints are not automatically reusable.

## Measured context volume, not claimed token savings

The entry is 16.4% smaller by bytes. On one declared static helper example, reading all references plus the source and entry would load 43,422 bytes. The bounded payload plus the same entry loads 8,733 bytes, 79.9% fewer bytes, retaining the declared helper contract. This is an illustrative static context-volume comparison, not a paired model experiment, actual token/credit savings or correctness generalization.

The packet planning estimate is 1,478 tokens using ceil(UTF-8 bytes / 3 × 1.25). It is not a provider tokenizer or guaranteed upper bound. The entry alone is approximately 1,295 tokens using the separate characters/4 size proxy. Both are explicitly estimates. Actual host tokens, billable usage and model-by-model quality remain UNMEASURED/NOT_TESTED. See `validation/token-smoke/token-efficiency.json` for the calculation and exact retained/omitted spans.

## Models and host usage

The workflow supports agent-capable Codex, Opus and other model families through simple instructions, JSON schemas and terminal commands. compact reduces work size and repair attempts for unknown/older/lower-capability choices; frontier provides more room for hard semantic review. These are engineering workload profiles, not model specifications or capability certifications. Every profile keeps the same source/test/behavior gates.

Select an exact currently available label in your Copilot client. Availability depends on plan/client/organization and changes over time; some older Codex/Opus releases are retired. Do not infer context windows from provider advertising or a family name. Record the actual host window when known; leave it null otherwise. A non-Agent-Skills host can load one packet manually with operator-run commands, but that is not automatic discovery.

Current official docs describe Copilot CLI /usage and /context, and VS Code's context usage control and Agent Debug Logs. The package accepts reviewed normalized per-call counters; it does not automatically parse arbitrary native logs or intercept the host. Live terminal alerts require a live normalized feed. Without telemetry, packet estimates and declared estimated events provide local budget alerts and remain labeled as estimates. Native credit limits can provide additional host-level spending protection where supported; they are separate soft limits, not enforced by this package.

## Start using it

1. Extract into the customer repository without overwriting customizations. Install the same pinned requirements with Python 3.12.
2. Copy templates/budget-compact.json to a working budget.json. Set the model label from the host. Keep an unknown context window null; choose your own session planning cap.
3. Build a reviewed packet request from frozen source ranges, all required behavior/assertion/data obligations and dependency interfaces.
4. Run context, load only the ready payload, implement one slice and validate. After each batch/repair record available normalized usage, or use a trusted normalized JSONL feed for usage-watch.
5. Checkpoint before compaction/model changes. Revalidate rule-version changes. Never weaken quality gates to fit a cheaper model or budget.

Read the skill README and references/model-profiles-and-alerts.md for commands, examples, host guidance and limits. All tool --help entries match implemented arguments.

Customer migration coverage/accuracy remain INDETERMINATE because the actual customer source, target framework, manual steps and application environment have not been supplied. The original Selenium browser differential, full browser/OS/parallel matrix, real GitHub Actions run and live Copilot model/telemetry validation remain unverified. See `CONTINUATION.json` for the remaining customer inputs and steps.
