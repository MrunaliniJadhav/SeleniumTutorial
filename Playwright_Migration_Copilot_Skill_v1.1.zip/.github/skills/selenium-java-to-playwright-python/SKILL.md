---
name: selenium-java-to-playwright-python
description: Migrate Selenium Java, TestNG/JUnit and page objects to Playwright Python/pytest. Use for assessment, overload/override migration, token-budgeted batches, validation, usage alerts and safe resume.
---

# Selenium Java → Playwright Python

Use Python 3.12 and this folder's requirements.txt. Set TOOL to scripts/migration_tool.py in this skill. Run from the repository root. Copilot performs semantic edits; the CLI is not a compiler. Read repository policies first.

## Preserve

Keep Java originals, user edits, exact data, assertions, negative paths and observable contracts. Use sync Playwright/pytest by default. Preserve true overriding and super initialization. Java overloads must become one runtime implementation or explicit compatible dispatch, never duplicate Python definitions. Do not invent DOM, APIs, credentials or execution evidence. The legacy-bulk profile forbids customer app execution, framework edits, new helpers and data substitution.

## Budget before loading context

Default to compact with unknown/older models; use balanced for ordinary migration and frontier for difficult semantics when available. Profile names are workload budgets, not advertised model limits. Read [model profiles and alerts](references/model-profiles-and-alerts.md) once when selecting/changing profiles.

Build a reviewed manifest from inventory ranges, required obligations and dependency interfaces. Run `python TOOL context --root . --request packet-request.json --budget budget.json --cache-dir .migration/context-cache --payload-out .migration/input-001.json --out .migration/packet-001.json`. Load only the ready input file. Never load a blocked packet or drop required contracts to fit. Load at most the relevant reference sections, not the full library.

After every batch/repair, record available per-call telemetry with `python TOOL usage --event usage-event.json --ledger .migration/usage.json --budget budget.json --out .migration/usage-001.json`. Normalized counts are host-reported or estimated, never guessed as exact. With a normalized JSONL feed, `usage-watch --feed usage.jsonl --ledger .migration/usage.json --budget budget.json --once --out .migration/watch-001.json` emits terminal alerts. No hidden host-counter access is claimed.

At 60% warn and reduce optional context; at 80% checkpoint/compact; at 90% stop starting model work and split/resume. Report `TOKEN WARNING/CHECKPOINT/STOP: measure, used/limit, host-reported or estimated, next action`. Unknown telemetry/window must remain unknown. Checkpoint before switching model or chat; preserve IDs, contracts, hashes, failures and next command.

## Execute one verified slice

1. Use doctor and ingest. Inventory actual source/build/resources; parser failures are blockers. Review syntax-only dependencies, inherited/implicit contracts, dynamic provider rows, helper assertions and browser/suite variants. Freeze reviewed source cases, units, assertions and obligations externally before scoring.
2. Use plan for provider-first batches with cycles intact. Select an ordinary flow, risky Java construct, shared dependency and observation failure for the pilot. Build the bounded packet above. Use scaffold only for a new target; inspect existing conventions otherwise.
3. Implement source dependencies and tests together. Trace manual ID/step/expected → Java call/implementation → Python node/assertion/data → evidence. Missing or different behavior remains blocked.
4. Use check and validate for static checks, real collection, unit/type/lint checks and permitted browser runs. Retain first-attempt results, independent oracle references and content-bound evidence. After two unchanged-cause repairs in compact mode (three otherwise), checkpoint and escalate or continue independent work.
5. Use metrics/report, then write a schema-valid checkpoint. Run resume before the next batch; review source/resource/target/config/rule/environment drift. Never overwrite edited targets or shrink a frozen denominator. All exact commands and examples are in [README](README.md).

## Load by trigger

- Scope/profile/cutover: [contract](references/contract-and-workflow.md).
- Overload/override/conversions: [Java semantics](references/java-semantics.md).
- Locator/wait/event: [Playwright patterns](references/playwright-patterns.md).
- Fixtures/providers/reports/CI: [pytest](references/pytest-and-ci.md).
- Percentages/evidence: [validation](references/validation-and-metrics.md).
- Known defect: its entry in [failure catalog](references/failure-catalog.md).
- Source spans/interfaces/resume: [context routing](references/context-routing.md).
- Current APIs/host availability: [sources](references/sources.md).

## Acceptance

Require >90% separately for verified tests/source, >95% behavior accuracy, every critical flow verified and full assertion/data retention for claimed units. Unknown counts, stale/missing evidence, hidden skips and retry-only success prevent acceptance. Model/profile changes never weaken gates. Report package validation separately from customer targets. Run benchmark for synthetic checks; do not infer customer success.
