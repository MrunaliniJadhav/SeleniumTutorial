#!/usr/bin/env python3
"""Deterministic support for agent-led semantic migration. Never a compiler."""

from __future__ import annotations
import argparse
import ast
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

VERSION = "1.1.0"
BASE = Path(__file__).resolve().parents[1]
EXCLUDED = {".git", ".venv", "node_modules", "target", "build", "__pycache__", "migration_reports", ".migration"}


class Invalid(ValueError):
    """Invalid or incomplete evidence."""


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(value):
    raw = value if isinstance(value, bytes) else json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    return digest(Path(path).read_bytes())


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def unique(items, label):
    result = {}
    for item in items:
        key = item["id"]
        if key in result:
            raise Invalid(f"duplicate {label}: {key}")
        result[key] = item
    return result


def under(root, relative):
    p = Path(relative)
    if p.is_absolute() or ".." in p.parts:
        raise Invalid(f"unsafe relative path: {relative}")
    target = (Path(root).resolve() / p).resolve()
    if not target.is_relative_to(Path(root).resolve()):
        raise Invalid("symlink escape")
    return target


def atomic(path, value, expected=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink() or any(p.is_symlink() for p in path.parents):
        raise Invalid("refuse symlink output")
    if path.exists() and (expected is None or sha(path) != expected):
        raise Invalid(f"output exists or edited: {path}; choose a fresh path")
    payload = json.dumps(value, indent=2, ensure_ascii=False) + "\n"
    with tempfile.NamedTemporaryFile("w", dir=path.parent, encoding="utf-8", delete=False) as f:
        f.write(payload)
        name = f.name
    os.replace(name, path)


def schema(kind, data):
    from jsonschema import Draft202012Validator

    errors = sorted(
        Draft202012Validator(read(BASE / "schemas" / f"{kind}.json")).iter_errors(data), key=lambda e: str(e.path)
    )
    if errors:
        raise Invalid("; ".join(e.message for e in errors[:8]))


def versions():
    result = {"python": sys.version.split()[0], "toolkit": VERSION}
    for name in ["tree-sitter", "tree-sitter-java", "pytest", "playwright", "pytest-playwright", "jsonschema"]:
        try:
            result[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            result[name] = None
    return result


def run_command(argv, cwd, timeout=120):
    if not isinstance(argv, list) or not argv or not all(isinstance(a, str) for a in argv):
        raise Invalid("command must be a nonempty argument list")
    start = now()
    try:
        p = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, timeout=timeout, shell=False)
        return {
            "command": argv,
            "cwd": str(Path(cwd).resolve()),
            "start": start,
            "end": now(),
            "returncode": p.returncode,
            "stdout": p.stdout[-16000:],
            "stderr": p.stderr[-8000:],
        }
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {
            "command": argv,
            "cwd": str(Path(cwd).resolve()),
            "start": start,
            "end": now(),
            "returncode": 3,
            "stdout": "",
            "stderr": type(exc).__name__,
        }


def java_inventory(root):
    from tree_sitter import Language, Parser
    import tree_sitter_java

    parser = Parser(Language(tree_sitter_java.language()))
    root = Path(root).resolve()
    units, assertions, obligations, tests, risks, resources = [], [], [], [], [], []
    files = {}
    java_paths = []
    for p in sorted(root.rglob("*")):
        if not p.is_file() or any(x in EXCLUDED for x in p.relative_to(root).parts):
            continue
        if p.is_symlink() or not p.resolve().is_relative_to(root):
            raise Invalid(f"symlink source: {p}")
        rel = p.relative_to(root).as_posix()
        if p.suffix == ".java":
            java_paths.append(p)
        elif p.suffix in {
            ".xml",
            ".json",
            ".csv",
            ".xlsx",
            ".properties",
            ".feature",
            ".yml",
            ".yaml",
            ".gradle",
        } or p.name.startswith("build.gradle"):
            resources.append({"path": rel, "hash": sha(p), "status": "discovered"})
    # Respect git ignore without trusting it to make scope complete.
    if (root / ".git").exists():
        kept = []
        for p in java_paths:
            r = subprocess.run(
                ["git", "check-ignore", "-q", "--", str(p.relative_to(root))], cwd=root, capture_output=True
            )
            if r.returncode == 0:
                risks.append(
                    {
                        "path": p.relative_to(root).as_posix(),
                        "reason": "ignored Java source excluded; scope approval required",
                    }
                )
            else:
                kept.append(p)
        java_paths = kept
    for p in java_paths:
        rel = p.relative_to(root).as_posix()
        raw = p.read_bytes()
        tree = parser.parse(raw)
        if tree.root_node.has_error:
            raise Invalid(f"Java parse failed: {rel}")
        files[rel] = sha(p)

        def txt(n):
            return raw[n.start_byte : n.end_byte].decode("utf-8") if n else ""

        def walk(n):
            yield n
            for ch in n.named_children:
                yield from walk(ch)

        package = next(
            (
                txt(n).removeprefix("package ").rstrip(";").strip()
                for n in tree.root_node.named_children
                if n.type == "package_declaration"
            ),
            "",
        )
        for n in walk(tree.root_node):
            if n.type not in {"method_declaration", "constructor_declaration"}:
                continue
            owners = []
            parent = n.parent
            while parent:
                if parent.type in {
                    "class_declaration",
                    "interface_declaration",
                    "enum_declaration",
                    "record_declaration",
                }:
                    owners.append(txt(parent.child_by_field_name("name")))
                parent = parent.parent
            owner = ".".join(reversed(owners))
            name = txt(n.child_by_field_name("name"))
            params = n.child_by_field_name("parameters")
            types = []
            for ch in params.named_children if params else []:
                if ch.type in {"formal_parameter", "spread_parameter"}:
                    types.append(
                        "".join(txt(ch.child_by_field_name("type")).split())
                        + ("..." if ch.type == "spread_parameter" else "")
                    )
            signature = name + "(" + ",".join(types) + ")"
            uid = rel + "::" + ".".join(filter(None, [package, owner, signature]))
            modifiers = next((x for x in n.named_children if x.type == "modifiers"), None)
            annotations = (
                [txt(a) for a in walk(modifiers) if a.type in {"annotation", "marker_annotation"}] if modifiers else []
            )
            body = n.child_by_field_name("body")
            nodes = list(walk(body)) if body else []
            calls, locators, interactions, data, config = [], [], [], [], []
            aids, oids = [], []
            for call in [c for c in nodes if c.type == "method_invocation"]:
                cname = txt(call.child_by_field_name("name"))
                ctext = txt(call)
                calls.append(
                    {"name": cname, "text": ctext, "line": call.start_point.row + 1, "resolution": "unresolved"}
                )
                if cname.startswith("assert") or cname in {"verify", "checkThat", "fail"}:
                    aid = uid + ":assert:" + str(len(aids))
                    assertions.append({"id": aid, "source_id": uid, "text": ctext, "line": call.start_point.row + 1})
                    aids.append(aid)
                if txt(call.child_by_field_name("object")).split(".")[-1] == "By" and cname in {
                    "xpath",
                    "cssSelector",
                    "id",
                    "name",
                    "linkText",
                    "partialLinkText",
                    "className",
                    "tagName",
                }:
                    locators.append({"kind": cname, "text": ctext})
                if cname in {
                    "click",
                    "sendKeys",
                    "clear",
                    "get",
                    "submit",
                    "selectByVisibleText",
                    "switchTo",
                    "accept",
                    "dismiss",
                }:
                    interactions.append(ctext)
                if cname in {"getProperty", "getenv", "getProperties"}:
                    config.append(ctext)
                if cname in {"sleep", "waitForTimeout"}:
                    risks.append({"id": uid, "reason": "fixed-wait", "line": call.start_point.row + 1})
            for literal in [
                c for c in nodes if c.type in {"string_literal", "decimal_integer_literal", "null_literal"}
            ]:
                data.append(txt(literal))
            # Candidate obligations require contract review; never an automatic complete semantic oracle.
            for a in aids:
                oid = a + ":behavior"
                obligations.append(
                    {
                        "id": oid,
                        "source_id": uid,
                        "assertion_id": a,
                        "critical": False,
                        "oracle": "source assertion candidate; reviewer must freeze contract",
                        "status": "discovered",
                    }
                )
                oids.append(oid)
            unit = {
                "id": uid,
                "path": rel,
                "range": [n.start_point.row + 1, n.end_point.row + 1],
                "fqn": ".".join(filter(None, [package, owner, name])),
                "signature": signature,
                "module": str(Path(rel).parent),
                "kind": n.type,
                "annotations": annotations,
                "provider_names": [
                    txt(x.child_by_field_name("value")).strip('"')
                    for x in walk(modifiers)
                    if x.type == "element_value_pair" and txt(x.child_by_field_name("key")) == "dataProvider"
                ]
                if modifiers
                else [],
                "calls": calls,
                "dependencies": [],
                "assertion_ids": aids,
                "obligation_ids": oids,
                "locators": locators,
                "interactions": interactions,
                "data": data,
                "configuration": config,
                "source_hash": files[rel],
                "critical": False,
                "risk": [],
                "symbol_resolution": "syntax-only",
                "status": "discovered",
            }
            units.append(unit)
            is_test = any(
                a.split("(")[0].split(".")[-1]
                in {
                    "@Test",
                    "@ParameterizedTest",
                    "@RepeatedTest",
                    "@TestFactory",
                    "Test",
                    "ParameterizedTest",
                    "RepeatedTest",
                    "TestFactory",
                }
                or a.startswith("@Test")
                for a in annotations
            )
            # Tree-sitter retains complete annotation text, including qualification.
            is_test = is_test or any(
                a.lstrip("@").split("(")[0].split(".")[-1]
                in {"Test", "ParameterizedTest", "RepeatedTest", "TestFactory"}
                for a in annotations
            )
            if is_test:
                dynamic = any(
                    x in " ".join(annotations)
                    for x in ["dataProvider", "ParameterizedTest", "RepeatedTest", "TestFactory", "invocationCount"]
                )
                disabled = any(
                    x in " ".join(annotations) for x in ["Disabled", "Ignore", "enabled=false", "enabled = false"]
                )
                tests.append(
                    {
                        "id": uid + ":case",
                        "source_id": uid,
                        "data_id": None if dynamic else "default",
                        "count_known": not dynamic,
                        "disabled": disabled,
                        "status": "discovered",
                    }
                )
                if dynamic:
                    risks.append(
                        {"id": uid, "reason": "dynamic cases require source-run discovery; denominator unknown"}
                    )
        for token in [
            "ThreadLocal",
            "PageFactory",
            "getDeclaredMethod",
            "JavascriptExecutor",
            "InternetExplorerDriver",
            "Robot",
            "dependsOnMethods",
            "SoftAssert",
        ]:
            if token in raw.decode("utf-8"):
                risks.append({"path": rel, "reason": token})
    by_name = {}
    for u in units:
        by_name.setdefault(u["signature"].split("(")[0], []).append(u["id"])
    for u in units:
        candidates = set()
        for provider in u["provider_names"]:
            candidates.update(by_name.get(provider, []))
        for c in u["calls"]:
            candidates.update(by_name.get(c["name"], []))
        u["dependencies"] = sorted(candidates - {u["id"]})
        if len(by_name[u["signature"].split("(")[0]]) > 1:
            u["risk"].append("overload-or-override-resolution-required")
    result = {
        "schema_version": 1,
        "tool_version": VERSION,
        "created": now(),
        "root": str(root),
        "files": files,
        "resources": resources,
        "units": units,
        "tests": tests,
        "assertions": assertions,
        "obligations": obligations,
        "risks": risks,
        "analysis_complete": False,
        "case_count_known": bool(tests) and all(t["count_known"] for t in tests),
        "contract_review": "required",
        "limitations": [
            "Syntax-only call candidates, not Java type resolution.",
            "Review inheritance, implicit constructors, class-level TestNG tests, fluent assertions, XML and dynamic cases before freezing.",
        ],
    }
    result["snapshot"] = digest(
        {k: result[k] for k in ["files", "resources", "units", "tests", "assertions", "obligations"]}
    )
    return result


def dependency_batches(inv, size=4):
    # Tarjan SCC: cycles are never split, dependencies are emitted before consumers.
    units = unique(inv["units"], "unit")
    index, indices, low, stack, onstack, components = 0, {}, {}, [], set(), []

    def visit(v):
        nonlocal index
        indices[v] = low[v] = index
        index += 1
        stack.append(v)
        onstack.add(v)
        for w in units[v]["dependencies"]:
            if w not in units:
                raise Invalid("orphan dependency")
            if w not in indices:
                visit(w)
                low[v] = min(low[v], low[w])
            elif w in onstack:
                low[v] = min(low[v], indices[w])
        if low[v] == indices[v]:
            component = []
            while True:
                w = stack.pop()
                onstack.remove(w)
                component.append(w)
                if w == v:
                    break
            components.append(sorted(component))

    for v in sorted(units):
        if v not in indices:
            visit(v)
    batches, batch = [], []
    for c in components:
        if batch and len(batch) + len(c) > size:
            batches.append(batch)
            batch = []
        batch += c
    if batch:
        batches.append(batch)
    return {
        "schema_version": 1,
        "snapshot": inv["snapshot"],
        "batches": batches,
        "pilot_candidates": [u["id"] for u in inv["units"] if u["risk"] or u["locators"]][:5],
        "blockers": ["Review candidate dependencies and freeze complete source obligations before semantic claims."],
    }


def static_check(root):
    findings = []
    for p in sorted(Path(root).rglob("*.py")):
        if any(x in EXCLUDED for x in p.relative_to(root).parts):
            continue
        try:
            tree = ast.parse(p.read_text(encoding="utf-8"), filename=str(p))
        except SyntaxError as exc:
            findings.append({"path": str(p), "line": exc.lineno, "rule": "PY-SYNTAX"})
            continue

        def add(n, rule):
            findings.append({"path": str(p), "line": getattr(n, "lineno", 0), "rule": rule})

        for scope in [tree] + [
            n for n in ast.walk(tree) if isinstance(n, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef))
        ]:
            names = set()
            for n in scope.body:
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    decorators = [ast.unparse(d) for d in n.decorator_list]
                    if any(d.endswith("overload") for d in decorators):
                        continue
                    if n.name in names:
                        add(n, "PY-DUPLICATE-DEFINITION")
                    names.add(n.name)
        for n in ast.walk(tree):
            if isinstance(n, ast.Call):
                f = ast.unparse(n.func)
                if f.split(".")[-1] in {"sleep", "wait_for_timeout"}:
                    add(n, "PW-FIXED-WAIT")
                if any(
                    k.arg == "force" and isinstance(k.value, ast.Constant) and k.value.value is True for k in n.keywords
                ):
                    add(n, "PW-FORCE")
                if f.endswith(".nth"):
                    add(n, "PW-POSITIONAL")
                if "pytest.skip" in f or "pytest.xfail" in f:
                    add(n, "PY-HIDDEN-SKIP")
                if f.split(".")[-1] in {"findElement", "sendKeys", "getByRole", "toBeVisible", "waitForTimeout"}:
                    add(n, "PY-WRONG-API")
                if f.endswith("wait_for_load_state") and any(
                    isinstance(a, ast.Constant) and a.value == "networkidle" for a in n.args
                ):
                    add(n, "PW-NETWORKIDLE")
            if isinstance(n, ast.Attribute) and n.attr == "first":
                add(n, "PW-POSITIONAL")
            if isinstance(n, ast.Assert) and isinstance(n.test, ast.Constant) and n.test.value:
                add(n, "PY-ASSERT-TRUE")
            if isinstance(n, ast.ExceptHandler) and (
                n.type is None or ast.unparse(n.type) in {"Exception", "BaseException"}
            ):
                if not any(isinstance(x, ast.Raise) for x in ast.walk(n)):
                    add(n, "PY-SWALLOWED-FAILURE")
    return {
        "schema_version": 1,
        "status": "failed" if findings else "static_passed",
        "findings": findings,
        "limitations": [
            "Risk detector only; inspect assertion semantics, aliases, fixture scopes, and data preservation manually."
        ],
    }


def check_drift(inv, root):
    changed = []
    tracked = dict(inv["files"])
    tracked.update({r["path"]: r["hash"] for r in inv["resources"]})
    for rel, expected in tracked.items():
        path = under(root, rel)
        if not path.exists() or sha(path) != expected:
            changed.append(rel)
    current = {
        p.relative_to(root).as_posix()
        for p in Path(root).rglob("*.java")
        if not any(x in EXCLUDED for x in p.relative_to(root).parts)
    }
    changed += sorted(current - set(inv["files"]))
    return sorted(set(changed))


def calculate(inv, bundle, root):
    schema("inventory", inv)
    schema("evidence", bundle)
    for key in ["units", "tests", "assertions", "obligations"]:
        unique(inv[key], key)
    uid_set = {u["id"] for u in inv["units"]}
    for key in ["tests", "assertions", "obligations"]:
        if any(x["source_id"] not in uid_set for x in inv[key]):
            raise Invalid("orphan baseline source reference")
    for u in inv["units"]:
        required_a = {a["id"] for a in inv["assertions"] if a["source_id"] == u["id"]}
        required_o = {o["id"] for o in inv["obligations"] if o["source_id"] == u["id"]}
        if required_a != set(u["assertion_ids"]) or required_o != set(u["obligation_ids"]):
            raise Invalid("unit obligation/assertion links incomplete")
        if set(u["dependencies"]) - uid_set:
            raise Invalid("orphan baseline dependency")
    if (
        digest({k: inv[k] for k in ["files", "resources", "units", "tests", "assertions", "obligations"]})
        != inv["snapshot"]
    ):
        raise Invalid("baseline tampered or denominator changed")
    if check_drift(inv, Path(root)):
        raise Invalid("source drift")
    if bundle["snapshot"] != inv["snapshot"]:
        raise Invalid("stale snapshot")
    records = unique(bundle["records"], "evidence")
    mappings = unique(bundle["mappings"], "mapping")
    all_ids = set().union(*(set(unique(inv[k], k)) for k in ["units", "tests", "assertions", "obligations"]))
    for r in records.values():
        if set(r["source_ids"]) - all_ids:
            raise Invalid("orphan source evidence")
        if not r["artifacts"] or not r["targets"] or not r["commands"]:
            raise Invalid("missing runtime artifacts/targets/commands")
        if r["environment"] != versions():
            raise Invalid("environment version drift")
        for entry in r["targets"] + r["artifacts"]:
            p = under(root, entry["path"])
            if not p.exists() or sha(p) != entry["hash"]:
                raise Invalid("stale target/artifact")
        for c in r["commands"]:
            if c["returncode"] != 0 and r["outcome"] == "pass":
                raise Invalid("contradictory pass command")
        if r["outcome"] == "pass" and (not r["first_attempt_pass"] or r["retry_only"]):
            raise Invalid("retry-only pass cannot verify")
        # Evidence authenticity is review-controlled; hashes establish identity, not semantic truth.
        if r["outcome"] == "pass" and (not r["oracle_reference"] or not r["reviewed_by"]):
            raise Invalid("unreviewed equivalence oracle")
    covered = set()
    failed_ids = {i for r in records.values() if r["outcome"] == "fail" for i in r["source_ids"]}
    for m in mappings.values():
        if not m["target_nodes"]:
            raise Invalid("missing target node mapping")
        if not m["source_ids"] or set(m["source_ids"]) - all_ids:
            raise Invalid("orphan/empty mapping")
        if not m["evidence_ids"] or set(m["evidence_ids"]) - set(records):
            raise Invalid("orphan/missing evidence")
        if m["status"] == "equivalence_verified":
            for eid in m["evidence_ids"]:
                r = records[eid]
                if r["outcome"] != "pass" or not set(m["source_ids"]).issubset(r["source_ids"]):
                    raise Invalid("unsupported verified mapping")
            if set(m["source_ids"]) & failed_ids:
                raise Invalid("contradictory pass/fail evidence")
            covered.update(m["source_ids"])
    total_t, total_u = len(inv["tests"]), len(inv["units"])
    assertions = {a["id"] for a in inv["assertions"]}
    source_units = unique(inv["units"], "units")
    proposed = set(bundle["proposed_source_ids"])
    if proposed - set(source_units):
        raise Invalid("unknown proposed source unit")
    if covered.intersection(source_units) - proposed:
        raise Invalid("verified source missing from proposed scope")
    applicable = [o for o in inv["obligations"] if o["source_id"] in proposed]
    p = sum(o["id"] in covered for o in applicable)
    f = sum(
        any(o["id"] in r["source_ids"] and r["outcome"] == "fail" for r in records.values())
        for o in applicable
        if o["id"] not in covered
    )
    x = len(applicable) - p - f
    verified_u = {
        u["id"]
        for u in inv["units"]
        if u["id"] in covered
        and all(i in covered for i in u["assertion_ids"] + u["obligation_ids"])
        and not u.get("blockers")
        and all(d in covered for d in u["dependencies"])
    }
    verified_t = {
        t["id"]
        for t in inv["tests"]
        if t["id"] in covered and t["source_id"] in verified_u and not t["disabled"] and t["count_known"]
    }

    def pct(n, d):
        return 100 * n / d if d else None

    t_pct, u_pct, b_pct = pct(len(verified_t), total_t), pct(len(verified_u), total_u), pct(p, len(applicable))
    known = inv["analysis_complete"] and inv["case_count_known"] and inv["contract_review"] == "frozen"
    critical = all(o["id"] in covered for o in inv["obligations"] if o["critical"])
    gates = {
        "complete_inventory": known,
        "test_coverage": t_pct is not None and t_pct > 90,
        "source_coverage": u_pct is not None and u_pct > 90,
        "behavior_accuracy": b_pct is not None and b_pct > 95,
        "critical": critical,
        "assertions": all(
            a in covered
            for a in assertions
            if next(x for x in inv["assertions"] if x["id"] == a)["source_id"] in proposed
        ),
        "no_hidden_skips": not any(t["disabled"] and t["id"] in covered for t in inv["tests"]),
        "mandatory_checks": bundle["mandatory_checks_passed"],
    }
    return {
        "schema_version": 1,
        "status": "accepted" if all(gates.values()) else "incomplete",
        "gates": gates,
        "tests": {"verified": len(verified_t), "total": total_t, "pct": t_pct if known else None},
        "source": {"verified": len(verified_u), "total": total_u, "pct": u_pct if known else None},
        "behavior": {"P": p, "F": f, "X": x, "pct": b_pct if known else None},
        "denominator_status": "KNOWN" if known else "INDETERMINATE",
        "automation_pct": "UNMEASURED",
        "note": "Evidence needs independent review; this tool cannot authenticate an oracle or prove arbitrary semantic equivalence.",
    }


def ingest(paths):
    results = []
    for name in paths:
        p = Path(name)
        item = {"name": p.name, "hash": sha(p), "format": p.suffix, "status": "extracted"}
        if p.suffix.lower() == ".xlsx":
            import openpyxl

            w = openpyxl.load_workbook(p, read_only=True, data_only=True)
            item["sheets"] = {
                s.title: [[str(v) if v is not None else None for v in row] for row in s.values] for s in w
            }
            w.close()
        else:
            try:
                item["lines"] = p.read_text(encoding="utf-8-sig").splitlines()
            except UnicodeDecodeError:
                item["status"] = "decode_blocked"
        results.append(item)
    return {"schema_version": 1, "attachments": results}


def doctor():
    result = {
        "schema_version": 1,
        "versions": versions(),
        "executables": {x: shutil.which(x) for x in ["java", "javac", "mvn", "gradle", "git"]},
        "browsers": {},
    }
    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            for name in ["chromium", "firefox", "webkit"]:
                b = getattr(p, name)
                result["browsers"][name] = {"path": b.executable_path, "installed": Path(b.executable_path).exists()}
    except ImportError:
        result["browsers"]["status"] = "dependency missing"
    result["status"] = "available" if all(result["versions"].values()) else "environment_unavailable"
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="op", required=True)
    for name in [
        "doctor",
        "ingest",
        "inventory",
        "plan",
        "check",
        "validate",
        "metrics",
        "report",
        "resume",
        "benchmark",
        "scaffold",
        "context",
        "usage",
        "usage-watch",
    ]:
        p = sub.add_parser(name)
        p.add_argument("--config", help="Optional schema-valid configuration; legacy profile restricts execution.")
        p.add_argument("--out", required=True, help="Fresh JSON output path; existing files are preserved.")
        if name in {"inventory", "check", "validate", "metrics", "resume", "context"}:
            p.add_argument("--root", required=True)
        if name in {"plan", "metrics", "report", "resume"}:
            p.add_argument("--inventory", required=True)
        if name in {"metrics", "report"}:
            p.add_argument("--evidence", required=True)
        if name == "ingest":
            p.add_argument("inputs", nargs="+")
        if name == "validate":
            p.add_argument("--commands", required=True, help="JSON list of argv lists; trusted operator input only")
        if name == "resume":
            p.add_argument("--checkpoint", required=True)
        if name == "scaffold":
            p.add_argument("--destination", required=True)
        if name in {"context", "usage", "usage-watch"}:
            p.add_argument("--budget", required=True, help="Model-neutral context/usage policy JSON")
        if name == "context":
            p.add_argument("--request", required=True, help="Reviewed source-span/contract packet request JSON")
            p.add_argument("--cache-dir", help="Content-addressed packet cache; preserve and verify existing entries")
            p.add_argument("--payload-out", help="Fresh file containing only ready model input, without audit metadata")
        if name == "usage":
            p.add_argument("--event", required=True, help="Normalized per-call usage JSON; no invented host telemetry")
            p.add_argument("--ledger", required=True, help="Persistent usage ledger; single writer")
        if name == "usage-watch":
            p.add_argument("--feed", required=True, help="Normalized per-call JSONL usage feed")
            p.add_argument("--ledger", required=True, help="Persistent usage ledger; single writer")
            p.add_argument("--once", action="store_true")
            p.add_argument("--seconds", type=int, default=60)
    args = parser.parse_args()
    try:
        config = read(args.config) if args.config else None
        if config is not None:
            schema("config", config)
            if hasattr(args, "root") and args.op == "inventory":
                if str(Path(args.root).resolve()) not in [str(Path(p).resolve()) for p in config["source_roots"]]:
                    raise Invalid("inventory root outside configured source roots")
        if args.op in {"context", "usage", "usage-watch"}:
            from context_budget import build_packet, record_event, watch_events

            budget = read(args.budget)
            schema("budget", budget)
            if args.op == "context":
                request = read(args.request)
                schema("packet-request", request)
                result = build_packet(args.root, request, budget)
                if args.cache_dir and result["payload"] is not None:
                    cached_path = Path(args.cache_dir) / (result["cache_key"] + ".json")
                    if cached_path.exists():
                        if read(cached_path) != result:
                            raise Invalid("context cache changed; preserve edits and rebuild in a fresh cache")
                        result["cache_hit"] = True
                    else:
                        atomic(cached_path, result)
                        result["cache_hit"] = False
                if args.payload_out and result["status"] == "ready":
                    atomic(args.payload_out, result["payload"])
                    result["payload_path"] = args.payload_out
                if result["alert"]["level"] != "ok":
                    print(json.dumps({"token_alert": result["alert"]}), file=sys.stderr)
            elif args.op == "usage":
                event = read(args.event)
                schema("usage-event", event)
                result = record_event(event, args.ledger, budget, atomic)
                for item in result["alerts"]:
                    if item["level"] != "ok":
                        print(json.dumps({"token_alert": item}), file=sys.stderr)
            else:
                result = watch_events(
                    args.feed,
                    args.ledger,
                    budget,
                    atomic,
                    lambda line: print(line, file=sys.stderr, flush=True),
                    args.once,
                    args.seconds,
                )
        elif args.op == "doctor":
            result = doctor()
        elif args.op == "ingest":
            result = ingest(args.inputs)
        elif args.op == "inventory":
            result = java_inventory(args.root)
            schema("inventory", result)
        elif args.op == "plan":
            result = dependency_batches(read(args.inventory))
        elif args.op == "check":
            result = static_check(args.root)
        elif args.op == "validate":
            commands = read(args.commands)
            if not isinstance(commands, list):
                raise Invalid("commands must be a JSON list")
            if config and (config["profile"] == "legacy-bulk" or not config["allow_customer_execution"]):
                if any("--collect-only" not in c or "pytest" not in c for c in commands):
                    raise Invalid("configured profile permits pytest collection only; application execution blocked")
            executions = [run_command(c, args.root) for c in commands]
            result = {
                "schema_version": 1,
                "environment": versions(),
                "executions": executions,
                "status": "runtime_passed"
                if all(c["returncode"] == 0 for c in executions) and executions
                else "failed",
                "note": "Command evidence only. Semantic review and node-level mappings remain required.",
            }
        elif args.op in {"metrics", "report"}:
            inv = read(args.inventory)
            root = args.root if args.op == "metrics" else inv["root"]
            result = calculate(inv, read(args.evidence), root)
            if args.op == "report":
                md = Path(args.out).with_suffix(".md")
                if md.exists():
                    raise Invalid("report Markdown already exists")
                md.write_text(
                    "# Migration evidence report\n\n```json\n" + json.dumps(result, indent=2) + "\n```\n",
                    encoding="utf-8",
                )
        elif args.op == "resume":
            cp, inv = read(args.checkpoint), read(args.inventory)
            schema("checkpoint", cp)
            if cp["rule_version"] != VERSION:
                raise Invalid("checkpoint rule version drift")
            if cp["snapshot"] != inv["snapshot"]:
                raise Invalid("checkpoint baseline mismatch")
            changed = check_drift(inv, Path(args.root))
            affected = {u["id"] for u in inv["units"] if u["path"] in changed}
            while True:
                extra = {u["id"] for u in inv["units"] if set(u["dependencies"]) & affected}
                if extra <= affected:
                    break
                affected |= extra
            targets = [
                x["path"]
                for x in cp["targets"]
                if not under(args.root, x["path"]).exists() or sha(under(args.root, x["path"])) != x["hash"]
            ]
            result = {
                "schema_version": 1,
                "status": "blocked" if changed or targets else "ready",
                "source_drift": changed,
                "invalidated_ids": sorted(affected),
                "edited_targets_preserved": targets,
                "next_task": cp["next_task"],
                "remaining_ids": cp["remaining_ids"],
                "rule_version": VERSION,
            }
        elif args.op == "benchmark":
            result = run_command(
                [
                    sys.executable,
                    "-m",
                    "pytest",
                    "tests",
                    "benchmarks/python",
                    "-q",
                    "--junitxml=" + str(Path(args.out).resolve().with_suffix(".xml")),
                ],
                BASE,
            )
            result["status"] = "runtime_passed" if result["returncode"] == 0 else "failed"
        else:
            dest = Path(args.destination)
            if dest.exists():
                raise Invalid("scaffold destination exists; preserve edits")
            shutil.copytree(BASE / "templates" / "project", dest)
            result = {"schema_version": 1, "status": "generated", "destination": str(dest.resolve())}
        if config is not None:
            result["config_hash"] = digest(config)
        atomic(args.out, result)
        print(json.dumps({"output": args.out, "status": result.get("status", "generated")}, indent=2))
        return (
            1
            if result.get("status") in {"failed", "incomplete", "blocked", "checkpoint"}
            else 3
            if result.get("status") == "environment_unavailable"
            else 0
        )
    except (Invalid, KeyError, ValueError, TypeError, OSError) as exc:
        print(json.dumps({"status": "invalid_input", "error": str(exc)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
