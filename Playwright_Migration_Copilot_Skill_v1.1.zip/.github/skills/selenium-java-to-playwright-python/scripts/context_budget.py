"""Model-neutral context packets and normalized usage alerts; no hidden Copilot API."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import time

ENGINE_VERSION = "1.1.0"


def rules_fingerprint():
    root = Path(__file__).resolve().parents[1]
    paths = [Path(__file__), root / "scripts/migration_tool.py", root / "SKILL.md"] + sorted(
        (root / "references").glob("*.md")
    )
    return content_hash({str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})


PROFILES = {
    "compact": {
        "input_budget_tokens": 4000,
        "output_reserve_tokens": 1000,
        "host_reserve_tokens": 4000,
        "max_batch_units": 1,
        "max_repairs": 2,
    },
    "balanced": {
        "input_budget_tokens": 6000,
        "output_reserve_tokens": 1500,
        "host_reserve_tokens": 6000,
        "max_batch_units": 3,
        "max_repairs": 3,
    },
    "frontier": {
        "input_budget_tokens": 10000,
        "output_reserve_tokens": 2500,
        "host_reserve_tokens": 8000,
        "max_batch_units": 5,
        "max_repairs": 3,
    },
}
LEVELS = [("stop", 0.90), ("checkpoint", 0.80), ("warning", 0.60)]


def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def content_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def estimate(text):
    # Explicit planning proxy, NOT an actual Codex/Claude tokenizer or guaranteed bound.
    return math.ceil(len(text.encode("utf-8")) / 3 * 1.25)


def positive(value, name, nullable=False):
    if nullable and value is None:
        return
    if type(value) is not int or value <= 0:
        raise ValueError(f"{name} must be a positive integer")


def policy(data):
    if not isinstance(data, dict) or data.get("profile") not in PROFILES:
        raise ValueError("budget profile must be compact, balanced, or frontier")
    allowed = {
        "schema_version",
        "profile",
        "model_label",
        "context_window_tokens",
        "session_limit_tokens",
        "input_budget_tokens",
        "output_reserve_tokens",
        "host_reserve_tokens",
        "max_batch_units",
        "max_repairs",
    }
    if set(data) - allowed or data.get("schema_version") != 1:
        raise ValueError("unknown budget field or schema version")
    result = {**PROFILES[data["profile"]], **data}
    for key in [
        "input_budget_tokens",
        "output_reserve_tokens",
        "host_reserve_tokens",
        "max_batch_units",
        "max_repairs",
    ]:
        positive(result[key], key)
    result.setdefault("context_window_tokens", None)
    result.setdefault("session_limit_tokens", None)
    result.setdefault("model_label", "user-selected; capability not verified")
    if not isinstance(result["model_label"], str):
        raise ValueError("model_label must be a string")
    positive(result["context_window_tokens"], "context_window_tokens", True)
    positive(result["session_limit_tokens"], "session_limit_tokens", True)
    window = result["context_window_tokens"]
    if window is not None and window <= result["output_reserve_tokens"] + result["host_reserve_tokens"]:
        raise ValueError("context window cannot fit reserved output and host overhead")
    result["effective_input_budget_tokens"] = (
        min(result["input_budget_tokens"], window - result["output_reserve_tokens"] - result["host_reserve_tokens"])
        if window
        else result["input_budget_tokens"]
    )
    result["policy_hash"] = content_hash(result)
    return result


def alert(measure, used, limit, basis):
    if limit is None:
        return {
            "measure": measure,
            "level": "unknown",
            "used": used,
            "limit": None,
            "basis": basis,
            "message": "Limit/telemetry unavailable; inspect the host. No remaining-capacity claim.",
        }
    ratio = used / limit
    level = next((label for label, threshold in LEVELS if ratio >= threshold), "ok")
    actions = {
        "ok": "Continue bounded work.",
        "warning": "Reduce optional context and report this warning.",
        "checkpoint": "Checkpoint now; finish the current safe operation, then compact or start a new chat.",
        "stop": "Stop starting model work; checkpoint and split or resume in a fresh supported context.",
    }
    return {
        "measure": measure,
        "level": level,
        "used": used,
        "limit": limit,
        "ratio": round(ratio, 4),
        "basis": basis,
        "message": actions[level],
    }


def safe_path(root, relative):
    root = Path(root).resolve()
    rel = Path(relative)
    if rel.is_absolute() or ".." in rel.parts:
        raise ValueError("packet paths must be relative and within root")
    path = root / rel
    if path.is_symlink() or any(p.is_symlink() for p in path.parents if p != root and p.is_relative_to(root)):
        raise ValueError("packet symlinks are not allowed")
    if not path.resolve().is_relative_to(root):
        raise ValueError("packet path escape")
    return path


def build_packet(root, request, budget):
    cfg = policy(budget)
    allowed = {"schema_version", "task", "required_contract_ids", "dependencies_complete", "unit_count", "files"}
    if not isinstance(request, dict) or set(request) - allowed or request.get("schema_version") != 1:
        raise ValueError("invalid packet request")
    task = request["task"]
    if not isinstance(task, str) or not task.strip():
        raise ValueError("packet task must be nonempty text")
    needed = request["required_contract_ids"]
    if (
        not isinstance(needed, list)
        or not needed
        or any(not isinstance(x, str) or not x for x in needed)
        or len(set(needed)) != len(needed)
    ):
        raise ValueError("required_contract_ids must be nonempty unique strings")
    if type(request["dependencies_complete"]) is not bool:
        raise ValueError("dependencies_complete must be boolean")
    positive(request["unit_count"], "unit_count")
    if not isinstance(request["files"], list) or not request["files"]:
        raise ValueError("packet files must be nonempty")
    fragments, duplicate_count, seen, represented = [], 0, set(), set()
    for spec in request["files"]:
        if set(spec) - {"path", "start_line", "end_line", "required", "role", "contract_ids", "sha256"}:
            raise ValueError("unknown packet fragment field")
        if type(spec.get("required")) is not bool or spec.get("role") not in {
            "instruction",
            "source",
            "interface",
            "obligation",
            "reference",
            "log",
        }:
            raise ValueError("fragment needs required boolean and a supported role")
        if not isinstance(spec.get("contract_ids"), list) or any(x not in needed for x in spec["contract_ids"]):
            raise ValueError("fragment references unknown contract")
        path = safe_path(root, spec["path"])
        if path.stat().st_size > 1024 * 1024:
            raise ValueError("packet file exceeds 1 MiB; extract a deliberate narrow text file first")
        raw = path.read_bytes()
        sha = hashlib.sha256(raw).hexdigest()
        if "sha256" in spec and spec["sha256"] != sha:
            raise ValueError("stale packet fragment hash")
        lines = raw.decode("utf-8-sig").splitlines(keepends=True)
        start, end = spec.get("start_line", 1), spec.get("end_line", len(lines))
        if type(start) is not int or type(end) is not int or not 1 <= start <= end <= len(lines):
            raise ValueError("invalid inclusive packet line span")
        key = (str(path.resolve()), start, end)
        if key in seen:
            # Merge required/contract declarations so ordering cannot drop a required fragment.
            previous = next(f for f in fragments if f["_key"] == key)
            previous["required"] |= spec["required"]
            previous["contract_ids"] = sorted(set(previous["contract_ids"]) | set(spec["contract_ids"]))
            duplicate_count += 1
            continue
        seen.add(key)
        fragments.append(
            {
                "_key": key,
                "path": spec["path"],
                "start_line": start,
                "end_line": end,
                "sha256": sha,
                "required": spec["required"],
                "role": spec["role"],
                "contract_ids": list(spec["contract_ids"]),
                "text": "".join(lines[start - 1 : end]),
            }
        )
    for f in fragments:
        f.pop("_key")
        if f["required"]:
            represented.update(f["contract_ids"])
    missing = sorted(set(needed) - represented)
    required = [f for f in fragments if f["required"]]
    optional = [f for f in fragments if not f["required"]]
    header = {"schema_version": 1, "task": task, "contracts": needed, "policy_hash": cfg["policy_hash"]}

    def packet_cost(fs):
        return estimate(json.dumps({**header, "fragments": fs}, ensure_ascii=False, separators=(",", ":")))

    req_cost = packet_cost(required)
    limit = cfg["effective_input_budget_tokens"]
    blockers = []
    if missing:
        blockers.append("Missing required contract fragments: " + ", ".join(missing))
    if not request["dependencies_complete"]:
        blockers.append("Dependency contracts not reviewed as complete")
    if request["unit_count"] > cfg["max_batch_units"]:
        blockers.append("Unit count exceeds profile; split without breaking a dependency cycle")
    if req_cost > limit:
        blockers.append(
            "Required context exceeds input budget; split or select an available stronger profile; never truncate contracts"
        )
    selected = list(required)
    omitted = []
    if not blockers:
        for f in optional:
            if packet_cost(selected + [f]) < limit * 0.80:
                selected.append(f)
            else:
                omitted.append(
                    {
                        "path": f["path"],
                        "start_line": f["start_line"],
                        "end_line": f["end_line"],
                        "reason": "optional context exceeds budget",
                    }
                )
    payload = {**header, "fragments": selected} if not blockers else None
    value = packet_cost(selected) if payload else req_cost
    warning = alert("packet_input_tokens", value, limit, "estimated_utf8_bytes_divided_by_3_times_1.25")
    # Packets at 90% are not dispatched, even if technically within the soft ceiling.
    if warning["level"] == "stop":
        blockers.append("90% packet stop threshold reached; split the packet before loading it")
        payload = None
    return {
        "schema_version": 1,
        "status": "blocked" if blockers else "checkpoint" if warning["level"] == "checkpoint" else "ready",
        "profile": cfg["profile"],
        "model_label": cfg["model_label"],
        "policy_hash": cfg["policy_hash"],
        "estimator": "planning proxy, not provider/host token accounting",
        "estimated_input_tokens": value,
        "required_estimated_tokens": req_cost,
        "context_window_tokens": cfg["context_window_tokens"],
        "output_reserve_tokens": cfg["output_reserve_tokens"],
        "host_reserve_tokens": cfg["host_reserve_tokens"],
        "alert": warning,
        "blockers": blockers,
        "duplicates_avoided": duplicate_count,
        "optional_omitted": omitted,
        "payload": payload,
        "cache_key": content_hash(
            {
                "rule_bundle_hash": rules_fingerprint(),
                "engine_version": ENGINE_VERSION,
                "request": request,
                "hashes": [f["sha256"] for f in fragments],
                "policy": cfg["policy_hash"],
            }
        ),
        "note": "Only payload is model input; keep audit metadata on disk. A stable cache key supports reuse, not guaranteed host cache hits.",
    }


def validate_event(event):
    allowed = {
        "schema_version",
        "event_id",
        "session_id",
        "turn_id",
        "model_label",
        "basis",
        "scope",
        "input_tokens",
        "output_tokens",
        "cached_input_tokens",
        "reasoning_tokens",
        "context_used_tokens",
        "context_window_tokens",
        "evidence_reference",
    }
    if not isinstance(event, dict) or set(event) - allowed or event.get("schema_version") != 1:
        raise ValueError("invalid normalized usage event")
    for key in ["event_id", "session_id", "turn_id", "model_label", "evidence_reference"]:
        if not isinstance(event.get(key), str) or not event[key].strip():
            raise ValueError(f"{key} is required text")
    if event.get("basis") not in {"host_reported", "estimated"} or event.get("scope") != "per_call":
        raise ValueError(
            "usage requires per_call input/output, with separate host_reported or estimated basis; never cumulative snapshots"
        )
    for key in ["input_tokens", "output_tokens", "cached_input_tokens", "reasoning_tokens", "context_used_tokens"]:
        value = event.get(key)
        if key in {"input_tokens", "output_tokens"} and value is None:
            raise ValueError("per-call input/output totals are required; zero is allowed")
        if value is not None and (type(value) is not int or value < 0):
            raise ValueError(f"{key} must be a nonnegative integer or null when unknown")
    positive(event.get("context_window_tokens"), "context_window_tokens", True)
    if event.get("cached_input_tokens") is not None and event["cached_input_tokens"] > event["input_tokens"]:
        raise ValueError("cached input is a subset of input total, not additive")
    if event.get("reasoning_tokens") is not None and event["reasoning_tokens"] > event["output_tokens"]:
        raise ValueError("reasoning tokens must be a known subset of output total; normalize native totals first")
    if (
        event.get("context_used_tokens") is not None
        and event.get("context_window_tokens") is not None
        and event["context_used_tokens"] > event["context_window_tokens"]
    ):
        raise ValueError("context usage exceeds reported window")
    return event


def summarize(events, budget, session_id):
    cfg = policy(budget)
    by_id = {}
    for event in events:
        validate_event(event)
        if event["event_id"] in by_id:
            raise ValueError("duplicate event in ledger")
        by_id[event["event_id"]] = event
    selected = [e for e in events if e["session_id"] == session_id]
    sums = {}
    warnings = []
    for basis in ["host_reported", "estimated"]:
        group = [e for e in selected if e["basis"] == basis]
        sums[basis] = {
            "events": len(group),
            "input_tokens": sum(e["input_tokens"] for e in group),
            "output_tokens": sum(e["output_tokens"] for e in group),
        }
        sums[basis]["total_tokens"] = sums[basis]["input_tokens"] + sums[basis]["output_tokens"]
        if group:
            warnings.append(
                alert("session_total_tokens", sums[basis]["total_tokens"], cfg["session_limit_tokens"], basis)
            )
    if sums["host_reported"]["events"] and sums["estimated"]["events"]:
        warnings.append(
            alert(
                "session_total_tokens",
                sums["host_reported"]["total_tokens"] + sums["estimated"]["total_tokens"],
                cfg["session_limit_tokens"],
                "mixed_host_and_estimate",
            )
        )
    latest = selected[-1] if selected else None
    if latest and latest.get("context_used_tokens") is not None:
        # A model switch can change the window. Use the event window, never silently reuse an old model limit.
        window = latest.get("context_window_tokens")
        if window is None and latest["model_label"] == cfg["model_label"]:
            window = cfg["context_window_tokens"]
        warnings.append(alert("current_context_tokens", latest["context_used_tokens"], window, latest["basis"]))
    else:
        warnings.append(alert("current_context_tokens", None, None, "unavailable"))
    rank = {"ok": 0, "unknown": 0, "warning": 1, "checkpoint": 2, "stop": 3}
    severity = max((a["level"] for a in warnings), key=lambda x: rank[x], default="unknown")
    telemetry = "host_reported" if sums["host_reported"]["events"] else "estimated_only" if selected else "unavailable"
    return {
        "schema_version": 1,
        "status": "blocked" if severity == "stop" else "checkpoint" if severity == "checkpoint" else "ready",
        "session_id": session_id,
        "model_labels": sorted({e["model_label"] for e in selected}),
        "telemetry": telemetry,
        "totals": sums,
        "alerts": warnings,
        "highest_alert": severity,
        "note": "Per-call cumulative spend is distinct from current context occupancy. Cache/reasoning subsets are not added twice. Unknown usage is not zero. No billed cost/credits are inferred.",
    }


def record_event(event, ledger, budget, writer):
    validate_event(event)
    path = Path(ledger)
    current = load_json(path) if path.exists() else {"schema_version": 1, "events": []}
    if current.get("schema_version") != 1 or set(current) != {"schema_version", "events"}:
        raise ValueError("invalid usage ledger")
    events = current["events"]
    old = next((e for e in events if e["event_id"] == event["event_id"]), None)
    if old is not None and old != event:
        raise ValueError("conflicting duplicate event; refusing double counting")
    if old is None:
        events = events + [event]
    summary = summarize(events, budget, event["session_id"])
    if old is None:
        prior_hash = hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
        writer(path, {"schema_version": 1, "events": events}, expected=prior_hash)
    summary["idempotent_replay"] = old is not None
    return summary


def watch_events(feed, ledger, budget, writer, emit, once=False, seconds=60):
    """Consume a normalized JSONL feed. No undocumented native Copilot log parsing."""
    if seconds <= 0 or seconds > 60:
        raise ValueError("watch duration must be 1..60 seconds; rerun or use an external supervisor")
    start = time.monotonic()
    processed, warned = set(), set()
    summaries = []
    while True:
        raw = Path(feed).read_text(encoding="utf-8")
        # Ignore an incomplete last line during live appends, but reject malformed complete lines.
        lines = raw.splitlines() if once or raw.endswith("\n") else raw.splitlines()[:-1]
        for line in lines:
            if not line.strip():
                continue
            event = json.loads(line)
            fingerprint = content_hash(event)
            if fingerprint in processed:
                continue
            summary = record_event(event, ledger, budget, writer)
            processed.add(fingerprint)
            summaries.append(summary)
            for a in summary["alerts"]:
                if a["level"] not in {"ok", "unknown"}:
                    key = (summary["session_id"], a["measure"], a["level"], a["basis"])
                    if key not in warned:
                        emit(json.dumps({"token_alert": a, "session_id": summary["session_id"]}, ensure_ascii=False))
                        warned.add(key)
        if once or time.monotonic() - start >= seconds:
            break
        time.sleep(min(0.5, max(0, seconds - (time.monotonic() - start))))
    return {
        "schema_version": 1,
        "status": summaries[-1]["status"] if summaries else "ready",
        "events_seen": len(processed),
        "alerts_emitted": len(warned),
        "last_summary": summaries[-1] if summaries else None,
        "note": "Alerts require normalized feed updates; this is not an IDE popup or a Copilot session interceptor.",
    }
