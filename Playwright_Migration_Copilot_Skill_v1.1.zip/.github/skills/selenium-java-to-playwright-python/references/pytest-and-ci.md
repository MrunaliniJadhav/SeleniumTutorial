# pytest, data and CI

Use sync pytest-playwright by default, function-scoped isolated page/context fixtures and reusable browser process. Keep app/library tests separate from browser tests. Async migration requires an explicit runner/plugin/event-loop decision; do not mix APIs.

Map JUnit/TestNG lifecycle, inherited teardown and always-run cleanup to yield fixtures/finally/context managers with correct scopes. Cleanup resources created before failure. A session fixture must not depend on a function page. Avoid test constructors and shared mutable class/session page objects.

Expand all JUnit/TestNG provider rows, invocation counts, XML parameters, environment/browser dimensions and inherited tests. Dynamic discovery is unknown until measured; never count unknown as zero. Keep stable pytest.param IDs, null/empty/Unicode data, selection markers, disabled/quarantined status and original assertions. Preserve data exactly under the supplied observation; parameterization of previously hardcoded customer data is a separate change. Existing providers must retain all rows.

dependsOnMethods/test ordering is an explicit workflow contract. Favor independent setup but never split a continuous transaction or rely on alphabetical order. Preserve expected exception types/messages/boundaries and soft assertions using an explicit tested aggregator. For BDD, preserve feature contracts only through a pinned validated integration.

Official plugin CLI options apply to its managed fixtures. Custom browser.new_context/new_page calls need their own option propagation, trace/screenshot hooks and cleanup. Pytest parallelism requires a separate pinned pytest-xdist dependency and isolated data/accounts/tenants/output paths. It is not supplied or claimed tested here. Test serial first. Cross-browser support is inferred from actual source requirements, not Java Grid capabilities copied blindly.

Reporting: use pytest-html for Python HTML results, allure-pytest for raw Allure results and optional external Allure CLI for rendering, plus pytest-playwright traces/screenshots/video. Do not install the Node runner to pretend its HTML reporter is native to pytest. Allure CLI and live external integrations remain separately validated.

Generated target install/run:

```bash
python -m pip install -r playwright_python/requirements.txt
python -m pip install -e playwright_python
python -m playwright install chromium
cd playwright_python
python -m pytest tests --collect-only -q
python -m ruff check src tests
python -m mypy src
python -m pytest tests --browser chromium --tracing retain-on-failure --screenshot only-on-failure --html=reports/pytest.html --self-contained-html --alluredir=allure-results --junitxml=test-results/junit.xml
```

All browser/action/assertion timeouts use milliseconds in Playwright; pytest process/job timeouts are separate settings owned by explicit plugins or CI. No retry plugin is included. First-attempt outcome remains distinct from rerun success. Ignore live auth, reports and secrets. Use repository secret variables. The CI example is locally inspected, not a remotely verified GitHub Actions run. Run source/target in isolated or reset environments to avoid double business mutations.
