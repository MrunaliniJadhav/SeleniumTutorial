# Model profiles, context budgets and usage alerts

## What is portable

The same source rules, schemas, Python commands and validation gates work without an OpenAI/Anthropic SDK or model-specific prompt syntax. Choose an agent-capable model available in your Copilot client and plan. Tool calling, file access and terminal execution come from the host. Older models can use the compact profile and one small contract at a time. If the host lacks Agent Skills, load SKILL.md and one ready packet manually; the operator runs terminal commands. This fallback is not automatic Agent Skills discovery.

A profile is an engineering work budget, not the provider's published context window. Do not infer context size, capability or availability merely from “Codex” or “Opus”. Record the exact picker label and current host window if exposed. Do not revive retired models or assume every model is enabled by the organization. This package cannot select a Copilot model, set its hidden reasoning/token options or prove performance on an untested model.

| Profile | Input estimate ceiling per packet | Reserved output | Reserved host/history/tools | Max source units per batch | Unchanged-cause repair cap |
| --- | ---: | ---: | ---: | ---: | ---: |
| compact | 4,000 | 1,000 | 4,000 | 1 | 2 |
| balanced | 6,000 | 1,500 | 6,000 | 3 | 3 |
| frontier | 10,000 | 2,500 | 8,000 | 5 | 3 |

Defaults are ceilings, not targets. Smaller complete packets are better. Warnings begin at 60% of a ceiling and a new packet is blocked at 90%; do not fill the available space. Where a host window is known, the effective packet ceiling is the smaller of the configured input ceiling and window minus output/host reserves. Reserves are planning assumptions; use current host occupancy too. A packet estimate alone does not include hidden prompts or previous conversation history.

Use compact for narrow ordinary methods, known-pattern conversions and tool-driven fixes. Use balanced for ordinary page/test slices with reviewed dependencies. Use frontier for ambiguous overload dispatch, inherited lifecycle, multi-module cycles, complex data providers and independent parity review. High risk requires stronger review or human resolution even if a compact model emits plausible code. Do not send the entire repository just because a frontier model supports more context. A unit/SCC that cannot fit must be redesigned into explicit reviewed interfaces or moved to an available larger profile, preserving every obligation.

All profiles retain the same >90% test/source, >95% behavior, critical-flow and assertion/data gates. No model is presumed accurate enough to skip execution.

## Build a bounded packet before a model call

Copy a budget template from templates/budget-compact.json (or balanced/frontier). Set model_label to the exact picker label. Leave context_window_tokens null until known from the host. session_limit_tokens is your own cumulative input+output planning cap, not a billing limit; the example 100,000 is editable. The compact default is appropriate when capabilities are unknown.

Create a reviewed packet request from inventory source ranges. Include all necessary source spans, obligations, dependency interfaces, canonical target examples and relevant rule sections. required_contract_ids must be frozen source identities, not invented completeness scores. dependencies_complete is an operator review attestation, not a parser guarantee. Mark every necessary fragment required. Only genuinely optional logs/background should be optional.

```bash
python TOOL context --root . --request packet-request.json --budget budget.json --cache-dir .migration/context-cache --payload-out .migration/input-001.json --out .migration/packet-001.json
```

The actual script path replaces TOOL. Read the small audit summary; load only input-001.json into the model, not audit metadata or cached prior packets. If blocked/checkpoint, do not load or act on an incomplete packet. Use fresh output paths. Missing required fragments, unreviewed dependencies, oversized required spans, stale hashes and excessive unit counts fail closed. Nothing required is silently trimmed. Optional fragments are added only while the resulting packet stays below the 80% checkpoint threshold; otherwise they are omitted with reasons. Required context is never dropped to avoid a warning/checkpoint. Equal path/spans are deduplicated and required metadata is merged. The cache is content-addressed by source/request/policy hashes; changed inputs/model settings invalidate reuse. Cache files are verified and user edits are preserved. This avoids model rereads and boilerplate, not guaranteed provider cache charges.

The estimator is ceil(UTF-8 bytes / 3 × 1.25), a deliberately cautious planning proxy. It is not a Codex, Claude or guaranteed upper-bound tokenizer. No exact provider token count is claimed. A larger window still needs host inspection. Different languages/source formatting can change tokenization.

## Alert semantics

| Usage ratio | Severity | Action |
| --- | --- | --- |
| <60% | OK | Continue bounded work |
| ≥60% | WARNING | Report usage and remove optional context |
| ≥80% | CHECKPOINT | Save state, then compact/start a new chat before more model work |
| ≥90% | STOP | Start no new model calls; split or resume after a fresh context/budget decision |
| Unknown | UNKNOWN | State missing telemetry/limit; use estimates and inspect the host |

Thresholds apply separately to packet input estimates, current context occupancy and cumulative session input+output. They are not interchangeable. A cumulative total may grow while context shrinks after compaction. Output reserves do not force the model's actual output cap. Recheck usage after long outputs and tool results. The CLI returns 1 for checkpoint/stop and emits token_alert JSON on stderr; warning remains exit 0. The skill requires a brief user-facing warning at these checkpoints. The tool cannot intercept all calls made outside the workflow or prevent the IDE from sending tokens.

Suggested message:

`TOKEN WARNING — packet estimate 2,600/4,000 (65%); remove optional logs before the next batch.`

Always say estimated or host-reported. No telemetry means no exact actual usage, remaining balance or money claim.

## Capture actual usage when the host exposes it

Copilot CLI documents /usage and /context. VS Code exposes a context control with token breakdown and Agent Debug Logs with usage/export tools. These are host features, not portable skill APIs. Availability/format varies by version. Prefer current host numbers and retain a provenance reference. Use native Copilot session credit limits where supported for actual credit-spend protection; a local token budget does not enforce billing.

Normalize one completed model call into the usage-event schema. The example file is synthetic and must be replaced, never submitted as measured usage. basis must be host_reported or estimated. scope must be per_call. Input includes cached input; output includes reasoning tokens if such counts are supplied as a subset. Do not add cached/reasoning subsets twice. If a host excludes reasoning from its output total, normalize that total first or leave reasoning unknown. Never ingest cumulative host session snapshots as per-call events. Use one stable event_id per original call. Input/output counts may be estimated when no host counters exist, but must stay labeled. Evidence references and labels are not authenticated by this tool.

```bash
python TOOL usage --event usage-event.json --ledger .migration/usage.json --budget budget.json --out .migration/usage-001.json
```

Exact replays are idempotent; conflicting duplicate IDs fail. Sessions are separate. Host and estimated totals remain separate; mixed planning alerts also prevent ignoring their combined volume. Unknown cache/reasoning/context fields remain null. No dollars, AI credits or entitlement balance are derived from token counts. Unknown/changed model context windows are not inherited blindly.

## Optional live terminal alerts

A trusted operator/export adapter may append normalized per-call JSON objects to usage.jsonl. The watcher consumes that format and emits terminal alerts as records arrive:

```bash
python TOOL usage-watch --feed usage.jsonl --ledger .migration/usage.json --budget budget.json --seconds 60 --out .migration/watch-001.json
```

For offline checks use --once. Watch duration is bounded to 60 seconds; a supervisor can restart it with fresh output names. Use one ledger writer. Live mode ignores a partially written last line until completed; malformed complete records fail visibly. Repeated feed records do not inflate usage. This is not a background service installed by the skill, an IDE popup, or a native Copilot-log parser. Automatic alerts need a live normalized feed; otherwise run usage at batch/repair boundaries. Do not claim native exports are automatically compatible with this schema. Review raw logs for secrets before sharing.

## Model changes and handoff

Checkpoint source/config/rule hashes, source IDs, preserved contracts, interfaces, current target hashes, evidence IDs, failure signature/repair count, usage basis and next command. Save this compact state to disk before /compact or switching models. In the new chat load the checkpoint and one ready packet. Current tool schemas remain simple JSON and Python argv lists. A non-agent host can follow the same steps with the operator executing commands. Resolve or escalate after the profile repair cap; never add retries or relax assertions to compensate for a weaker model.

No actual Codex/Opus comparative run was available here. Tests cover profiles, schemas, byte estimates, cache invalidation, fail-closed packets, ledger idempotency and alert boundaries. Behavioral accuracy on each selected model still requires the same representative customer pilot.

Current documented Copilot CLI credit limit commands (public preview; check /help in your installed version) are `/limits set max-ai-credits NUMBER` interactively or `copilot -p "YOUR PROMPT" --max-ai-credits NUMBER` for a task. GitHub documents a minimum of 30 credits and a soft limit that allows an in-progress response to finish. Choose your own cap; this skill does not set or raise it. Reference: https://docs.github.com/en/copilot/how-tos/copilot-cli/use-copilot-cli/set-session-limit .

When upgrading from 1.0, the toolkit rule version changes and old checkpoints/evidence must be reviewed and revalidated. A model change similarly preserves the frozen customer baseline and invalidates any model-specific context/window assumptions; it does not reset quality obligations or automatically discard cumulative session usage.
