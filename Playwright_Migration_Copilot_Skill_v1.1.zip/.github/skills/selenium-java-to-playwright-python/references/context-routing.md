# Context routing

Load SKILL.md once per session. Use the current checkpoint, next batch, source spans and already validated dependency contracts. References are opt-in by trigger, never concatenate every file.

| Trigger | Load |
| --- | --- |
| New assessment | contract/workflow plus inventory summary |
| Overload/override | java-semantics plus signatures and affected call sites |
| XPath/wait/browser race | playwright-patterns plus actual DOM and implicated source spans |
| Fixture/provider/reporting | pytest-and-ci plus relevant runner configuration |
| Metric claim/audit | validation-and-metrics plus frozen records and execution artifacts |
| Known observation | one failure rule and corresponding minimal regression |
| Resume | checkpoint, drift report, interfaces and next packet |

Packet fields: run/baseline/config/rule hashes; selected source IDs/ranges; dependency interfaces with inputs/returns/errors/side effects; relevant observations/rules; original obligations/assertions/data; target conventions; exact validation commands; unresolved questions. Keep completed logs and unrelated sources out. Use compact/balanced/frontier packet policies before loading source. The executable context command enforces complete contracts and soft ceilings; see model-profiles-and-alerts.md. Split oversized slices.

Read attachments once per hash and reuse their normalized ledger. Reuse approved unchanged inventory/interfaces rather than ask the model to count or reformat. Full automated incremental parse caching is a future capability; it is not claimed by this release. Deterministic formatting/scaffold prevents boilerplate regeneration. Patch the smallest failure and invalidate transitive consumers on provider drift. The context/usage/usage-watch commands now provide bounded packets, a ledger and alerts. Host counts require a normalized record/export feed; no hidden-host-counter integration is claimed. Record proxy estimates separately. No numerical token savings is claimed.

Load model-profiles-and-alerts.md when selecting a profile, recording telemetry, receiving a usage alert, or switching models. Cache validated interfaces and packet payloads by hashes. A provider cache hit is observable only from host telemetry; a local packet cache hit must not be presented as provider billing savings.
