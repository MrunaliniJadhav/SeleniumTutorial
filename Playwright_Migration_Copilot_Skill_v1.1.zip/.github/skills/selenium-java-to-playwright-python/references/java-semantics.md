# Java semantics

Python supports real method overriding. Preserve subclass dispatch, base initialization and super calls. Java @Override is not a Playwright annotation; Python typing.override is optional and version-dependent. Do not merge unrelated polymorphic behavior just because an observation calls it an “override”. Inspect actual signatures to distinguish overloading.

For Java overloads, retain every signature and call-site contract. Python ordinary duplicate definitions overwrite earlier ones. Use one runtime implementation with explicit dispatch/defaults or distinct internal methods plus a compatibility entry point. typing.overload is for static typing; it needs one concrete runtime implementation. Test same arity/different type, differing arity, kwargs if introduced, invalid inputs, bool versus int, missing sentinel versus None, and null ambiguity. Do not claim singledispatch reproduces Java compile-time overload resolution.

Constructors may need named factories or a sentinel-based initializer. Preserve field initialization order, side effects, exceptions, and mutable defaults. Map interfaces/abstract classes to appropriate protocols/ABCs only when it helps actual contracts. Composition is preferred for page capabilities; meaningful polymorphism remains inheritance.

Preserve static versus instance state. Java ThreadLocal is not an isolated pytest page. Avoid global mutable driver/context objects. Review reference identity versus equality, equals/hashCode, mutable collection aliasing, iteration order, enum/value conversions, null versus empty, Unicode and Java string/regex escaping. Java collections and Python generators have different evaluation/lifetime behavior.

Integer division truncates toward zero in Java; Python // floors. Avoid float conversion for large integer quotient. Decimal financial rounding must preserve explicit mode and precision. Check integer overflow where behavior matters. Preserve timezone, naive/aware distinctions, date parsing and locale. Java regex replacement syntax and Python re replacement escapes require tests.

Map try-with-resources/finally to context managers/fixtures with guaranteed cleanup. Do not swallow exceptions. Preserve checked error contracts through documented Python exceptions. Translate Java assertion library argument order intentionally. Preserve soft-assert aggregation and failure diagnostics rather than stopping at the first assertion accidentally.

Runnable before/after helper and held-out vectors are in benchmarks/java/Semantics.java and benchmarks/python/semantics.py. The JVM comparison is actual execution; it does not substitute for a Selenium browser baseline.
