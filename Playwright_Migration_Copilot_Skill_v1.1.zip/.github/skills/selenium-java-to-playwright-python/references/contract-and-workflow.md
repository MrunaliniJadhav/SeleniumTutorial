# Contract and workflow

Intake → syntax inventory → source-contract review and concrete discovery → frozen baseline → risk/dependency plan → pilot → batches → layered validation → report/checkpoint → cutover.

Only the automation boundary is in scope. Inventory src/main/java, src/test/java, resources, POM/Gradle, TestNG XML, feature files, data loaders, listeners, API/DB/file helpers, custom assertions, reports, and CI. Production application code is not automatically in scope. Gross counts and exclusions remain visible. Never drop hard cases to improve a percentage.

Candidate dependencies require compiler/classpath or source review. Group strongly connected components, verify providers before consumers, and select pilot risk before seeing results. Implicit constructors/field initializers and static blocks may encode contracts beyond explicit methods. Add them to the approved baseline. Source outcome, business expectations and manually documented steps are independent evidence, not target-generated confidence.

States are discovered, planned, generated, static_passed, runtime_passed, equivalence_verified, blocked, failed. A parse/collection pass cannot advance directly to equivalence_verified. Preserve exact source/test IDs when several overloads become one function or a workflow becomes multiple tests.

## Legacy bulk compatibility profile

The historical bulk prompt is an input profile, not authority to execute against absent Windows directories. It requires the canonical `test_core_display_project_58_59_60.py` and forbids `test_core_display_pcr_210.py` as a pattern. Inspect the canonical file when supplied, never invent its fixtures or APIs. Do not edit src/config/conftest/test_data/existing tests, introduce helpers, or run application tests under this profile. Collect only the newly generated test files.

Normalize quoted Windows paths and group all manual IDs sharing a Java source. Numeric IDs sort ascending. One file per connected group, one test per manual ID unless verified source semantics require a continuous transaction. A manual ID linked to multiple sources must preserve all steps and be flagged. Never duplicate setup performed once for a shared flow.

Trace every manual action/expected result to Java call, implementation, Python equivalent, assertion and runtime status. `Display_PCR.xlsx`, source Java, canonical Python and target framework are absent in this delivery, so manual-step parity remains blocked. Mapping-only attachments cannot establish executable test counts or behavior.

Missing equivalent behavior is a blocker. A comment describing it is diagnostic only. The old prompt's “use closest data row” and “use behaviorally different equivalent” shortcuts are rejected for acceptance: preserve original data and mark the step incomplete. Do not quietly substitute or weaken behavior.

## Batches, repair and cutover

Bound packets by dependency interface size and semantic complexity. Record source/target/config/rule/environment hashes before and after edits. On unchanged failure cause, stop after three repair iterations; retain blocker and continue independent batches. Do not blindly extend timeouts or add retries.

Cutover requires all declared gates, approved residual scope, runnable target CI, known unsupported capabilities, rollback command/owner, stable test-data isolation and retained evidence. Keep source code and Selenium CI until explicit retirement approval. Rollback restores original test selection/configuration; target output is additive.
