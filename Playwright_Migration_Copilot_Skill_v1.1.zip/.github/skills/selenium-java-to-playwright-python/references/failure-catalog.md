# Failure catalog

Synthetic regressions exercise rules. Customer-specific closure requires actual customer source/DOM/manual-step evidence.

## OBS-0001: XPath conversion

Validate selector identity and scope against actual DOM; retain supported XPath when appropriate.

Rule: PW-XPATH. Regression: test_xpath_and_rerender.

Evidence: MigrationObservationandImprovements.txt lines 5-6.

Blocker: Live customer selector regression blocked until DOM/source supplied.

## OBS-0002: Override compatibility

Distinguish real overriding from overloading; preserve dispatch and call contracts.

Rule: JAVA-DISPATCH. Regression: test_override_and_super, test_reject_ambiguous_overloads, test_typing_overload_is_allowed.

Evidence: MigrationObservationandImprovements.txt lines 8-11.

Run the named synthetic regression; do not infer customer closure.

## OBS-0003: Fixed waits

Replace arbitrary delays with observable readiness and event expectations.

Rule: PW-FIXED-WAIT. Regression: test_broken_migrations_detected, test_xpath_and_rerender.

Evidence: MigrationObservationandImprovements.txt lines 13-15.

Run the named synthetic regression; do not infer customer closure.

## OBS-0004: Hardcoded data

Document and preserve exact existing values; defer new parameterization.

Rule: DATA-PRESERVE. Regression: test_data_literals_preserved.

Evidence: MigrationObservationandImprovements.txt lines 17-19.

Blocker: Customer data regression blocked until source data supplied.

## OBS-0005: Functional traceability

Map each manual step/expected result to Java calls, target checks and execution.

Rule: TRACE-MANUAL. Regression: test_mapping_grouping.

Evidence: MigrationObservationandImprovements.txt lines 21-22.

Blocker: Step-level checks blocked: Display_PCR.xlsx and source implementations absent.

## OBS-0006: Centralized object repository

Reuse page/component scoped locator definitions without global mutable pages.

Rule: LOCATOR-OWNERSHIP. Regression: test_template_locator_reuse.

Evidence: MigrationObservationandImprovements.txt lines 27-28.

Run the named synthetic regression; do not infer customer closure.

## OBS-0007: Reporting

Use tested Python HTML and Allure adapters plus Playwright diagnostics.

Rule: REPORT-PYTHON. Regression: test_reporting_options.

Evidence: MigrationObservationandImprovements.txt lines 30-31.

Blocker: External Allure CLI rendering not available; raw results validated separately.

## OBS-0008: Framework standards

Use explicit fixtures, native APIs, linting and reproducible pinned templates.

Rule: FRAMEWORK-STANDARD. Regression: test_template_import_collection.

Evidence: MigrationObservationandImprovements.txt lines 33-34.

Run the named synthetic regression; do not infer customer closure.
