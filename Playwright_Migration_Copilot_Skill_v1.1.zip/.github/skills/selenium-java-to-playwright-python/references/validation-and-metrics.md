# Validation and metrics

Freeze reviewed gross inventory and exclusions externally before migration. Unknown dynamic case counts or incomplete behavior extraction prevent definitive whole-suite percentages. Syntax output is a candidate inventory; `analysis_complete`, complete concrete tests and `contract_review=frozen` require explicit review/source discovery. Never let target generation decide its own denominator.

T = frozen concrete source tests with all known data/browser/suite variants. U = logical source callable contracts (each overload separately), including initialization obligations. A = original assertion contracts, including hidden helper/teardown/soft assertions. O = source behavior obligations, independently extracted before target judgment. Non-callable resource/config status is separate.

Verified test coverage = 100 * T_verified / T_total. Verified source coverage = 100 * U_verified / U_total. Require each strictly >90, never average them. Verified behavior accuracy = 100 * P/(P+F+X), strictly >95. P is correct against a legitimate independent oracle, F is incorrect, X is missing/blocked/unexecuted. Every proposed migrated unit's obligations remain in the behavior denominator. 90 or 95 exactly fails. Zero legitimate denominator is NOT_APPLICABLE (current tool withholds a percentage and acceptance); unknown is INDETERMINATE. Automation/edit provenance is UNMEASURED unless independently tracked.

Require every baseline critical behavior verified, all source assertions and data variants retained for claimed units, no concealed skips/xfails/count loss, no duplicate runtime definitions, all mandatory checks passing, and no unresolved high severity defect. A retry-only pass is not first-attempt verification. Report generated/static/runtime/equivalence status separately.

## Evidence trust boundary

The schema requires source IDs, target nodes and hashes, command argument lists/cwd/timestamps/return codes, report artifact hashes, environment versions, first-attempt outcomes, oracle reference and reviewer. Many-to-many mappings are supported. Source/target/config/rule/fixture/environment drift invalidates affected evidence. Check referenced artifacts manually against selected test nodes, case IDs and outcomes; generic JUnit success is not independent behavioral parity. The tool does not authenticate reviewers or cryptographically prove that commands ran. CI should collect signed/controlled artifacts and review source contracts. Never claim a universal semantic oracle.

`validate` records actual commands but does not auto-promote mappings. A passing screenshot, matching keywords or model confidence cannot establish equivalence. Source failing tests remain failures even if reproduced; separate pre-existing defects from migration defects.

## Validation levels

L0: decode, schema, hashes, AST parse and source inventory integrity.
L1: compile/AST, import, lint, type checks and anti-pattern risk checks.
L2: real pytest node/data collection, helper tests and JVM differential vectors.
L3: deterministic local browser fixture and permitted customer pilot execution.
L4: independent source-vs-target controlled outcomes/side effects/errors.
L5: required browser matrix, repeated stability, parallel isolation and actual CI integration.

The delivered synthetic tests cover form/negative cases, XPath retention, rerender/list readiness, scoped duplicate labels, widgets, frames/shadow, events/upload/download, SPA/network, isolated/reused state, data variants, JVM overrides/overloads/division/decimal vectors, broken-code detector regressions, thresholds/evidence fraud and resume drift. Explicit gaps and blocked categories are listed in BUILD_REPORT and benchmark coverage. Tool tests are not customer coverage. Local Python benchmark plus a non-browser JVM helper is not a Selenium browser differential run.

Held-out vectors are fixed arithmetic cases outside the main Java output vector. They assess helper generalization only, not model migration quality. Lean/full-context model turns and tokens have not been measured; compare those modes on the same customer pilot with identical gates when host telemetry is available.
