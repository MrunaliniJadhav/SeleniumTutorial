# Sources and verification

Checked 22 October 2026. Official documentation is the technical authority; installed Playwright 1.55.0 API signatures and pytest 8.4.2 plugin behavior are the runtime authority. Web docs may describe later releases, so verify a feature against the installed package before use.

- GitHub Agent Skills: https://docs.github.com/en/copilot/concepts/customizations/agent-skills
- VS Code Agent Skills/frontmatter/location/progressive loading: https://code.visualstudio.com/docs/agent-customization/agent-skills
- Python pytest plugin: https://playwright.dev/python/docs/test-runners
- Python locators: https://playwright.dev/python/docs/locators
- Python assertions: https://playwright.dev/python/docs/test-assertions
- Actionability: https://playwright.dev/python/docs/actionability
- Events: https://playwright.dev/python/docs/events
- Auth: https://playwright.dev/python/docs/auth
- Network: https://playwright.dev/python/docs/network
- Browser install/version coupling: https://playwright.dev/python/docs/browsers
- networkidle caution: https://playwright.dev/python/docs/api/class-page#page-wait-for-load-state
- Python overriding: https://docs.python.org/3/tutorial/classes.html
- Python overload/override: https://docs.python.org/3/library/typing.html
- pytest fixtures: https://docs.pytest.org/en/stable/how-to/fixtures.html
- pytest parametrization: https://docs.pytest.org/en/stable/how-to/parametrize.html
- GitHub Actions checkout v4: https://github.com/actions/checkout/tree/v4
- setup-python v5: https://github.com/actions/setup-python/tree/v5
- upload-artifact v4: https://github.com/actions/upload-artifact/tree/v4

## User-supplied secondary references

These are background reading and prompts for verification, not technical authorities or proof of coverage/performance claims. All four were accessible during this conversation.

- https://medium.com/@vazidmansury2861/i-built-a-tool-that-migrates-your-selenium-cypress-webdriverio-tests-to-playwright-automatically-d2a6e57aedfb
- https://playwright.aims-ai.com/blog/selenium-to-playwright-migration
- https://www.deviqa.com/blog/how-to-migrate-from-selenium-to-playwright-a-complete-qa-guide/
- https://tayyabakmal.com/blog/selenium-to-playwright-migration-checklist/

Retain phased migration and validation as design choices. Verify any conversion rule against Java semantics and Python APIs. Do not inherit claimed percentages or timelines. TypeScript configs, Node reporter and worker options are not Python pytest configuration. Blanket networkidle advice is rejected in favor of product-specific readiness. Automated confidence scores are not semantic parity. Automatic deletion of Selenium sources conflicts with preservation policy.

Action version existence was cross-checked against official GitHub documentation/search results; direct branch pages were restricted. The workflow itself has not run on GitHub. References: https://docs.github.com/en/actions/tutorials/build-and-test-code/python and https://github.blog/changelog/2024-02-12-github-actions-artifacts-v4-is-now-generally-available/ . Optional Selenium 4.35.0 availability was checked at https://www.selenium.dev/blog/2025/selenium-4-35-released/ ; its Maven/browser example remains unexecuted.

## Token/model compatibility update (22 October 2026)

- Supported models, client availability and retirements: https://docs.github.com/en/copilot/reference/ai-models/supported-models
- Copilot CLI /usage, /context and session guidance: https://docs.github.com/en/copilot/how-tos/copilot-cli/cli-best-practices
- VS Code context usage control/compaction: https://code.visualstudio.com/docs/agents/run/sessions/manage-sessions
- VS Code token diagnostics/export: https://code.visualstudio.com/docs/agents/agent-troubleshooting/chat-debug-view

The current catalog lists GPT-5.3-Codex and multiple Claude Opus versions, while some earlier Codex/Opus releases are retired. Select what your current client actually offers; this package does not pin access to a retired model. No provider-advertised window is assumed to be your Copilot window. Native views are documented, but their telemetry/exports have not been exercised in a live Copilot session here. Local usage tools accept only their explicit normalized schema, not undocumented log formats.
