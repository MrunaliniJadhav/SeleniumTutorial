# Playwright Python patterns

Use native Locators with page/component scoped composition. Centralize repeated locator definitions inside the owning component or an explicit locator catalog, rather than a global mutable Page or giant generic driver facade. Existing architecture takes priority when it preserves contracts.

| Selenium intent | Python target |
| --- | --- |
| findElement/findElements | scoped Locator and explicit unique/count expectations |
| By.xpath | retain validated `locator("xpath=...")`; use role/label/test ID only with DOM evidence |
| sendKeys | fill replaces; press_sequentially/press preserve typing/keyboard semantics when required |
| clear then type | fill only when event behavior is equivalent |
| implicit wait/Thread.sleep | actionability and retrying expect, or a specific event/product readiness signal |
| select by value/label/index | select_option preserving exact mode; custom widgets need DOM interactions |
| hidden/not present | to_be_hidden versus to_have_count(0), preserving intended distinction |
| text/value/attribute/property | to_have_text/to_have_value/to_have_attribute or explicit DOM property check |
| frames | frame_locator chains preserving identity and scope |
| popup/download/file chooser | arm expect event before trigger; capture resulting object |
| alert/confirm/prompt | handler before trigger; preserve text, answer and accept/dismiss |
| remote WebDriver | verify provider protocol; not interchangeable with Playwright WS/CDP |

XPath is supported, not something to mechanically translate to CSS. Relative XPath, quoting, axes, namespace and shadow boundaries need actual DOM checks. XPath does not pierce shadow roots. Open shadow DOM works with supported Playwright locators; closed shadow roots and native desktop controls require explicit blockers/adapters.

Preserve strictness. `.first`, `.nth`, force clicks, JS clicks, and fallback-selector chains need source-contract justification and a narrow tested exception. No “green test” workaround. Exact checks must not become contains checks or truthiness. Immediate branch inspection is different from an assertion intended to retry. Collection snapshots and count accessors may race; establish expected collection readiness first.

Use expect_response/expect_popup/expect_download around the triggering action. Generic networkidle is discouraged as a test readiness strategy. Use product UI readiness or a relevant response with a user-visible postcondition. Auto-waiting does not wait for arbitrary business background work.

State reuse must account for user/tenant, expiry, cookies, local storage and storage mechanisms not captured by storage_state (notably session storage requires explicit setup). Keep state outside source control. Route/API setup may optimize unrelated setup only; do not bypass the UI behavior under test or silently replace a live integration with a mock. Service workers can affect request interception; document context changes.

Chromium CDP features are not universal across browsers. IE/ActiveX, desktop/native dialogs, CAPTCHA and live MFA require a supported test boundary and visible blockers. Visual assertions require a pinned Python comparison implementation and deterministic OS/fonts; screenshots alone are not semantic proof.
