"""Domain automation components."""
