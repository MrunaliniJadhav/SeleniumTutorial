import pytest


@pytest.fixture
def login_document(page):
    # Synthetic example only. Replace the page load with the evidenced customer URL/DOM.
    page.set_content("""<label>Username<input id="user"></label>
<label>Password<input id="password" type="password"></label>
<button onclick="document.querySelector('[role=status]').textContent =
 document.querySelector('#user').value === 'demo' && document.querySelector('#password').value === 'valid'
 ? 'Welcome demo' : 'Invalid credentials'">Sign in</button><p role="status"></p>""")
    return page
