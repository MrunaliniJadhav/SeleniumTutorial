import pytest
from migrated_automation.login import LoginPage


@pytest.mark.parametrize(
    "username,password,expected",
    [
        pytest.param("demo", "valid", "Welcome demo", id="valid"),
        pytest.param("demo", "wrong", "Invalid credentials", id="invalid"),
    ],
)
def test_login(login_document, username, password, expected):
    login = LoginPage(login_document)
    login.sign_in(username, password)
    login.expect_status(expected)
