from pathlib import Path
import copy
import json
import subprocess
import sys
import pytest
import context_budget as c
import migration_tool as m


@pytest.fixture
def budget():
    return {
        "schema_version": 1,
        "profile": "compact",
        "model_label": "user-selected-model",
        "context_window_tokens": None,
        "session_limit_tokens": 10000,
    }


@pytest.fixture
def packet_request(tmp_path):
    (tmp_path / "source.java").write_text("class X { void test() { check(); } }\n")
    (tmp_path / "optional.txt").write_text("optional context\n" * 3000)
    return {
        "schema_version": 1,
        "task": "Migrate this source contract.",
        "dependencies_complete": True,
        "unit_count": 1,
        "required_contract_ids": ["u1"],
        "files": [{"path": "source.java", "required": True, "role": "source", "contract_ids": ["u1"]}],
    }


@pytest.fixture
def event():
    return {
        "schema_version": 1,
        "event_id": "e1",
        "session_id": "s1",
        "turn_id": "t1",
        "model_label": "user-selected-model",
        "basis": "host_reported",
        "scope": "per_call",
        "input_tokens": 1000,
        "output_tokens": 500,
        "cached_input_tokens": 100,
        "reasoning_tokens": 100,
        "context_used_tokens": 6000,
        "context_window_tokens": 10000,
        "evidence_reference": "synthetic telemetry fixture; no actual Copilot session",
    }


@pytest.mark.parametrize("profile,limit,units", [("compact", 4000, 1), ("balanced", 6000, 3), ("frontier", 10000, 5)])
def test_model_profiles_keep_independent_budgets(budget, profile, limit, units):
    budget["profile"] = profile
    p = c.policy(budget)
    assert p["effective_input_budget_tokens"] == limit
    assert p["max_batch_units"] == units
    assert p["context_window_tokens"] is None


@pytest.mark.parametrize(
    "used,expected", [(5999, "ok"), (6000, "warning"), (8000, "checkpoint"), (9000, "stop"), (10001, "stop")]
)
def test_exact_alert_thresholds(used, expected):
    assert c.alert("tokens", used, 10000, "estimated")["level"] == expected


def test_unknown_telemetry_is_not_zero():
    a = c.alert("context", None, None, "unavailable")
    assert a["level"] == "unknown" and a["used"] is None and a["limit"] is None


def test_window_reserves_reduce_budget(budget):
    budget.update(context_window_tokens=8000, input_budget_tokens=4000)
    assert c.policy(budget)["effective_input_budget_tokens"] == 3000


def test_too_small_window_rejected(budget):
    budget["context_window_tokens"] = 5000
    with pytest.raises(ValueError):
        c.policy(budget)


def test_required_packet_and_optional_pruning(tmp_path, budget, packet_request):
    packet_request["files"].append({"path": "optional.txt", "required": False, "role": "log", "contract_ids": []})
    packet = c.build_packet(tmp_path, packet_request, budget)
    assert packet["status"] == "ready"
    assert packet["payload"]["fragments"][0]["contract_ids"] == ["u1"]
    assert len(packet["optional_omitted"]) == 1
    assert len(packet["payload"]["fragments"]) == 1


def test_no_required_contract_truncation(tmp_path, budget, packet_request):
    (tmp_path / "source.java").write_text("required contract\n" * 2000)
    packet = c.build_packet(tmp_path, packet_request, budget)
    assert packet["status"] == "blocked" and packet["payload"] is None
    assert "Required context exceeds" in " ".join(packet["blockers"])


def test_missing_dependency_blocks(tmp_path, budget, packet_request):
    packet_request["dependencies_complete"] = False
    assert c.build_packet(tmp_path, packet_request, budget)["payload"] is None


def test_missing_contract_blocks(tmp_path, budget, packet_request):
    packet_request["required_contract_ids"].append("u2")
    assert "u2" in str(c.build_packet(tmp_path, packet_request, budget)["blockers"])


def test_dedup_cannot_drop_required_metadata(tmp_path, budget, packet_request):
    first = copy.deepcopy(packet_request["files"][0])
    first["required"] = False
    first["contract_ids"] = []
    packet_request["files"].insert(0, first)
    result = c.build_packet(tmp_path, packet_request, budget)
    assert result["status"] == "ready" and result["duplicates_avoided"] == 1
    assert result["payload"]["fragments"][0]["required"]


def test_cache_key_changes_on_source_or_model(tmp_path, budget, packet_request):
    a = c.build_packet(tmp_path, packet_request, budget)
    assert a["cache_key"] == c.build_packet(tmp_path, packet_request, budget)["cache_key"]
    (tmp_path / "source.java").write_text("changed source\n")
    b = c.build_packet(tmp_path, packet_request, budget)
    assert a["cache_key"] != b["cache_key"]
    budget["model_label"] = "another-model"
    assert b["cache_key"] != c.build_packet(tmp_path, packet_request, budget)["cache_key"]


def test_stale_fragment_and_path_escape_rejected(tmp_path, budget, packet_request):
    packet_request["files"][0]["sha256"] = "0" * 64
    with pytest.raises(ValueError, match="stale"):
        c.build_packet(tmp_path, packet_request, budget)
    del packet_request["files"][0]["sha256"]
    packet_request["files"][0]["path"] = "../escape"
    with pytest.raises(ValueError, match="within root"):
        c.build_packet(tmp_path, packet_request, budget)


def test_compact_batch_size_is_enforced(tmp_path, budget, packet_request):
    packet_request["unit_count"] = 2
    assert c.build_packet(tmp_path, packet_request, budget)["status"] == "blocked"


def test_usage_subset_tokens_not_double_counted(event, budget):
    result = c.summarize([event], budget, "s1")
    assert result["totals"]["host_reported"]["total_tokens"] == 1500
    assert result["highest_alert"] == "warning"


def test_cumulative_spend_is_not_context_occupancy(event, budget):
    event.update(input_tokens=9000, output_tokens=0, cached_input_tokens=0, reasoning_tokens=0, context_used_tokens=100)
    result = c.summarize([event], budget, "s1")
    assert result["status"] == "blocked"
    assert next(a for a in result["alerts"] if a["measure"] == "current_context_tokens")["level"] == "ok"


def test_model_switch_does_not_reuse_old_context_window(event, budget):
    later = {
        **event,
        "event_id": "e2",
        "turn_id": "t2",
        "model_label": "other",
        "context_used_tokens": None,
        "context_window_tokens": None,
    }
    result = c.summarize([event, later], budget, "s1")
    assert next(a for a in result["alerts"] if a["measure"] == "current_context_tokens")["level"] == "unknown"


def test_estimates_are_separate_and_mixed_budget_is_checked(event, budget):
    a = {**event, "input_tokens": 4000, "output_tokens": 500, "context_used_tokens": None}
    b = {**a, "event_id": "e2", "basis": "estimated"}
    result = c.summarize([a, b], budget, "s1")
    assert result["status"] == "blocked"
    assert result["totals"]["host_reported"]["total_tokens"] == 4500
    assert result["totals"]["estimated"]["total_tokens"] == 4500
    assert any(x["basis"] == "mixed_host_and_estimate" for x in result["alerts"])


def test_usage_idempotency_and_conflict(tmp_path, event, budget):
    ledger = tmp_path / "ledger.json"
    first = c.record_event(event, ledger, budget, m.atomic)
    second = c.record_event(event, ledger, budget, m.atomic)
    assert second["idempotent_replay"]
    assert first["totals"] == second["totals"]
    with pytest.raises(ValueError, match="conflicting"):
        c.record_event({**event, "input_tokens": 2000}, ledger, budget, m.atomic)


@pytest.mark.parametrize(
    "patch",
    [
        {"input_tokens": -1},
        {"input_tokens": True},
        {"scope": "cumulative"},
        {"cached_input_tokens": 2000},
        {"reasoning_tokens": 600},
        {"basis": "actual_guess"},
        {"evidence_reference": ""},
    ],
)
def test_malformed_telemetry_rejected(event, patch):
    with pytest.raises(ValueError):
        c.validate_event({**event, **patch})


def test_empty_ledger_unknown_usage(budget):
    result = c.summarize([], budget, "s1")
    assert result["telemetry"] == "unavailable"
    assert result["highest_alert"] == "unknown"


def test_other_sessions_not_added(event, budget):
    assert c.summarize([event], budget, "s2")["totals"]["host_reported"]["events"] == 0


def test_live_feed_once_emits_warning_and_deduplicates(tmp_path, event, budget):
    feed = tmp_path / "feed.jsonl"
    feed.write_text(json.dumps(event) + "\n" + json.dumps(event) + "\n")
    seen = []
    result = c.watch_events(feed, tmp_path / "ledger.json", budget, m.atomic, seen.append, once=True)
    assert result["events_seen"] == 1 and len(seen) == 1
    assert "warning" in seen[0]


def test_cli_context_cache_and_alert_exit(tmp_path, budget, packet_request, event):
    for name, value in [("budget", budget), ("request", packet_request), ("event", event)]:
        (tmp_path / (name + ".json")).write_text(json.dumps(value))
    cli = [sys.executable, str(m.BASE / "scripts/migration_tool.py")]
    args = [
        "context",
        "--root",
        str(tmp_path),
        "--request",
        str(tmp_path / "request.json"),
        "--budget",
        str(tmp_path / "budget.json"),
        "--cache-dir",
        str(tmp_path / "cache"),
    ]
    a = subprocess.run(cli + args + ["--out", str(tmp_path / "packet1.json")], capture_output=True, text=True)
    b = subprocess.run(cli + args + ["--out", str(tmp_path / "packet2.json")], capture_output=True, text=True)
    assert a.returncode == b.returncode == 0, a.stderr + b.stderr
    assert not m.read(tmp_path / "packet1.json")["cache_hit"] and m.read(tmp_path / "packet2.json")["cache_hit"]
    event["context_used_tokens"] = 9000
    (tmp_path / "event.json").write_text(json.dumps(event))
    r = subprocess.run(
        cli
        + [
            "usage",
            "--event",
            str(tmp_path / "event.json"),
            "--ledger",
            str(tmp_path / "ledger.json"),
            "--budget",
            str(tmp_path / "budget.json"),
            "--out",
            str(tmp_path / "usage.json"),
        ],
        capture_output=True,
        text=True,
    )
    assert r.returncode == 1 and "token_alert" in r.stderr
    assert m.read(tmp_path / "usage.json")["highest_alert"] == "stop"


def test_unicode_uses_utf8_bytes():
    assert c.estimate("नमस्ते") > c.estimate("abcdef")


def test_packet_80_percent_requests_checkpoint(tmp_path, budget, packet_request):
    # Calibrate policy against the independently reported serialized payload size.
    first = c.build_packet(tmp_path, packet_request, budget)
    need = first["estimated_input_tokens"]
    budget["input_budget_tokens"] = int(need / 0.85)
    result = c.build_packet(tmp_path, packet_request, budget)
    assert result["alert"]["level"] == "checkpoint" and result["status"] == "checkpoint"


def test_usage_watch_checkpoint_exit_state(tmp_path, event, budget):
    event["context_used_tokens"] = 8000
    feed = tmp_path / "feed.jsonl"
    feed.write_text(json.dumps(event) + "\n")
    result = c.watch_events(feed, tmp_path / "usage.json", budget, m.atomic, lambda text: None, once=True)
    assert result["status"] == "checkpoint"


def test_payload_output_contains_model_input_only(tmp_path, budget, packet_request):
    (tmp_path / "budget.json").write_text(json.dumps(budget))
    (tmp_path / "request.json").write_text(json.dumps(packet_request))
    r = subprocess.run(
        [
            sys.executable,
            str(m.BASE / "scripts/migration_tool.py"),
            "context",
            "--root",
            str(tmp_path),
            "--request",
            str(tmp_path / "request.json"),
            "--budget",
            str(tmp_path / "budget.json"),
            "--payload-out",
            str(tmp_path / "input.json"),
            "--out",
            str(tmp_path / "audit.json"),
        ],
        capture_output=True,
        text=True,
    )
    assert r.returncode == 0, r.stderr
    payload = m.read(tmp_path / "input.json")
    assert "fragments" in payload and "optional_omitted" not in payload and "alert" not in payload


def test_packet_cache_user_edit_rejected(tmp_path, budget, packet_request):
    (tmp_path / "budget.json").write_text(json.dumps(budget))
    (tmp_path / "request.json").write_text(json.dumps(packet_request))
    args = [
        sys.executable,
        str(m.BASE / "scripts/migration_tool.py"),
        "context",
        "--root",
        str(tmp_path),
        "--request",
        str(tmp_path / "request.json"),
        "--budget",
        str(tmp_path / "budget.json"),
        "--cache-dir",
        str(tmp_path / "cache"),
    ]
    assert subprocess.run(args + ["--out", str(tmp_path / "a.json")], capture_output=True).returncode == 0
    entry = next((tmp_path / "cache").glob("*.json"))
    entry.write_text('{"edited":true}')
    result = subprocess.run(args + ["--out", str(tmp_path / "b.json")], capture_output=True, text=True)
    assert result.returncode == 2 and "cache changed" in result.stderr


def test_rule_change_invalidates_packet_cache_key(tmp_path, budget, packet_request, monkeypatch):
    before = c.build_packet(tmp_path, packet_request, budget)["cache_key"]
    monkeypatch.setattr(c, "rules_fingerprint", lambda: "changed-rules")
    assert c.build_packet(tmp_path, packet_request, budget)["cache_key"] != before


def test_optional_context_cannot_trigger_avoidable_checkpoint(tmp_path, budget, packet_request):
    needed = c.build_packet(tmp_path, packet_request, budget)["estimated_input_tokens"]
    (tmp_path / "optional.txt").write_text("x" * 800)
    packet_request["files"].append({"path": "optional.txt", "required": False, "role": "log", "contract_ids": []})
    full = c.build_packet(tmp_path, packet_request, {**budget, "profile": "frontier"})["estimated_input_tokens"]
    # Make the optional addition fit the nominal ceiling but cross the checkpoint threshold.
    budget["input_budget_tokens"] = int(full / 0.85)
    result = c.build_packet(tmp_path, packet_request, budget)
    assert needed < budget["input_budget_tokens"] * 0.8
    assert result["status"] == "ready" and result["optional_omitted"]
