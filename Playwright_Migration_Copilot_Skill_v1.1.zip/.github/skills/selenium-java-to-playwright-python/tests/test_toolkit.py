import copy
import json
from pathlib import Path
import subprocess
import sys
import pytest
import migration_tool as m


@pytest.fixture
def source(tmp_path):
    (tmp_path / "Flow.java").write_text("""package a;
class Base { int value(int x) { return x; } }
class Flow extends Base {
  @Override int value(int x) { return super.value(x); }
  int value(String x) { return x.length(); }
  @Test void happy() { Assert.assertEquals(value(1), 1); }
  @Test(dataProvider="rows") void dynamic(String x) { Assert.assertNotNull(x); }
}""")
    return tmp_path


def test_inventory_overloads_and_dynamic(source):
    inv = m.java_inventory(source)
    assert len(inv["units"]) == 5
    assert len(inv["tests"]) == 2
    assert len(inv["assertions"]) == 2
    assert not inv["case_count_known"]
    assert len({x["id"] for x in inv["units"]}) == 5
    assert not inv["analysis_complete"]
    m.schema("inventory", inv)


def test_parser_failure_visible(source):
    (source / "Broken.java").write_text("class Broken { void test( {")
    with pytest.raises(m.Invalid, match="parse failed"):
        m.java_inventory(source)


def test_provider_before_consumer_and_cycles():
    inv = {
        "snapshot": "s",
        "units": [
            {"id": "consumer", "dependencies": ["a"], "risk": [], "locators": []},
            {"id": "a", "dependencies": ["b"], "risk": [], "locators": []},
            {"id": "b", "dependencies": ["a"], "risk": [], "locators": []},
        ],
    }
    result = m.dependency_batches(inv, 1)
    assert result["batches"] == [["a", "b"], ["consumer"]]


@pytest.mark.parametrize(
    "code,rule",
    [
        ("def f():\n return 1\ndef f():\n return 2", "PY-DUPLICATE-DEFINITION"),
        ("import time\ntime.sleep(2)", "PW-FIXED-WAIT"),
        ("page.wait_for_timeout(2)", "PW-FIXED-WAIT"),
        ('page.locator("x").first.click()', "PW-POSITIONAL"),
        ('page.locator("x").click(force=True)', "PW-FORCE"),
        ("assert True", "PY-ASSERT-TRUE"),
        ("try:\n f()\nexcept Exception:\n result = True", "PY-SWALLOWED-FAILURE"),
        ('page.getByRole("button")', "PY-WRONG-API"),
        ('pytest.skip("migration")', "PY-HIDDEN-SKIP"),
        ('page.wait_for_load_state("networkidle")', "PW-NETWORKIDLE"),
    ],
)
def test_broken_migrations_detected(tmp_path, code, rule):
    (tmp_path / "broken.py").write_text(code)
    assert rule in {f["rule"] for f in m.static_check(tmp_path)["findings"]}


def test_typing_overload_is_allowed(tmp_path):
    (tmp_path / "good.py").write_text("""from typing import overload
@overload
def f(x: int) -> int: ...
@overload
def f(x: str) -> str: ...
def f(x):
    return x
""")
    assert m.static_check(tmp_path)["status"] == "static_passed"


def fixture_evidence(root, nt=100, nu=100, no=100, covered_t=100, covered_u=100, covered_o=100):
    (root / "Flow.java").write_text("class Flow {}")
    (root / "target.py").write_text("value = 1\n")
    (root / "run.xml").write_text('<testsuite tests="1" failures="0"/>')
    inv = {
        "schema_version": 1,
        "tool_version": m.VERSION,
        "created": m.now(),
        "root": str(root),
        "files": {"Flow.java": m.sha(root / "Flow.java")},
        "resources": [],
        "units": [
            {
                "id": f"u{i}",
                "path": "Flow.java",
                "signature": f"f{i}()",
                "dependencies": [],
                "assertion_ids": [],
                "obligation_ids": [],
                "source_hash": m.sha(root / "Flow.java"),
            }
            for i in range(nu)
        ],
        "tests": [
            {"id": f"t{i}", "source_id": f"u{i % nu}", "count_known": True, "disabled": False} for i in range(nt)
        ],
        "assertions": [],
        "obligations": [{"id": f"o{i}", "source_id": f"u{i % nu}", "critical": False} for i in range(no)],
        "risks": [],
        "analysis_complete": True,
        "case_count_known": True,
        "contract_review": "frozen",
        "limitations": [],
    }
    for o in inv["obligations"]:
        inv["units"][int(o["source_id"][1:])]["obligation_ids"].append(o["id"])
    inv["snapshot"] = m.digest(
        {k: inv[k] for k in ["files", "resources", "units", "tests", "assertions", "obligations"]}
    )
    ids = (
        [f"u{i}" for i in range(min(covered_u, nu))]
        + [f"t{i}" for i in range(min(covered_t, nt))]
        + [f"o{i}" for i in range(min(covered_o, no))]
    )
    record = {
        "id": "e1",
        "source_ids": ids,
        "targets": [{"path": "target.py", "hash": m.sha(root / "target.py")}],
        "artifacts": [{"path": "run.xml", "hash": m.sha(root / "run.xml")}],
        "commands": [
            {
                "command": ["python", "-m", "pytest"],
                "cwd": str(root),
                "start": m.now(),
                "end": m.now(),
                "returncode": 0,
                "stdout": "",
                "stderr": "",
            }
        ],
        "environment": m.versions(),
        "outcome": "pass",
        "first_attempt_pass": True,
        "retry_only": False,
        "oracle_reference": "synthetic test fixture, not customer proof",
        "reviewed_by": "unit-test",
    }
    evidence = {
        "schema_version": 1,
        "snapshot": inv["snapshot"],
        "records": [record],
        "mappings": [
            {
                "id": "map1",
                "source_ids": ids[:],
                "target_nodes": ["test_fixture"],
                "rule_ids": ["R1"],
                "contract_decision": "test fixture",
                "evidence_ids": ["e1"],
                "status": "equivalence_verified",
            }
        ],
        "proposed_source_ids": [f"u{i}" for i in range(nu)],
        "mandatory_checks_passed": True,
    }
    return inv, evidence


def freeze(inv):
    inv["snapshot"] = m.digest(
        {k: inv[k] for k in ["files", "resources", "units", "tests", "assertions", "obligations"]}
    )


@pytest.mark.parametrize("t,u,o", [(90, 100, 100), (100, 90, 100), (100, 100, 95)])
def test_exact_threshold_fails(tmp_path, t, u, o):
    inv, ev = fixture_evidence(tmp_path, covered_t=t, covered_u=u, covered_o=o)
    assert m.calculate(inv, ev, tmp_path)["status"] == "incomplete"


def test_all_gates_pass_on_synthetic_records(tmp_path):
    inv, ev = fixture_evidence(tmp_path)
    assert m.calculate(inv, ev, tmp_path)["status"] == "accepted"


@pytest.mark.parametrize(
    "mutation",
    [
        "stale-target",
        "stale-source",
        "duplicate",
        "orphan",
        "retry",
        "environment",
        "removed-row",
        "missing-artifact",
        "unreviewed",
        "contradiction",
    ],
)
def test_evidence_fraud_rejected(tmp_path, mutation):
    inv, ev = fixture_evidence(tmp_path)
    r = ev["records"][0]
    if mutation == "stale-target":
        (tmp_path / "target.py").write_text("changed")
    elif mutation == "stale-source":
        (tmp_path / "Flow.java").write_text("changed")
    elif mutation == "duplicate":
        ev["records"].append(copy.deepcopy(r))
    elif mutation == "orphan":
        r["source_ids"].append("nonexistent")
    elif mutation == "retry":
        r["retry_only"] = True
    elif mutation == "environment":
        r["environment"]["python"] = "wrong"
    elif mutation == "removed-row":
        inv["tests"].pop()
    elif mutation == "missing-artifact":
        r["artifacts"] = []
    elif mutation == "unreviewed":
        r["reviewed_by"] = ""
    elif mutation == "contradiction":
        r["commands"][0]["returncode"] = 1
    with pytest.raises(m.Invalid):
        m.calculate(inv, ev, tmp_path)


@pytest.mark.parametrize(
    "mutation", ["unknown", "zero", "disabled", "missing-obligation", "missing-assertion", "critical"]
)
def test_incomplete_gates(tmp_path, mutation):
    inv, ev = fixture_evidence(tmp_path)
    if mutation == "unknown":
        inv["case_count_known"] = False
    elif mutation == "zero":
        inv["tests"] = []
        ev["records"][0]["source_ids"] = [x for x in ev["records"][0]["source_ids"] if not x.startswith("t")]
        ev["mappings"][0]["source_ids"] = ev["records"][0]["source_ids"][:]
    elif mutation == "disabled":
        inv["tests"][0]["disabled"] = True
        inv["case_count_known"] = False
    elif mutation == "missing-obligation":
        inv["obligations"].append({"id": "missing", "source_id": "u0", "critical": True})
        inv["units"][0]["obligation_ids"].append("missing")
    elif mutation == "missing-assertion":
        inv["assertions"].append({"id": "missing", "source_id": "u0"})
        inv["units"][0]["assertion_ids"].append("missing")
    else:
        inv["obligations"][0]["critical"] = True
        ev["records"][0]["source_ids"].remove("o0")
        ev["mappings"][0]["source_ids"].remove("o0")
    freeze(inv)
    ev["snapshot"] = inv["snapshot"]
    assert m.calculate(inv, ev, tmp_path)["status"] == "incomplete"


def test_consolidation_does_not_shrink_denominator(tmp_path):
    inv, ev = fixture_evidence(tmp_path, nt=2, nu=2, no=2)
    assert m.calculate(inv, ev, tmp_path)["source"]["total"] == 2


def test_zero_unknown_report_no_100(tmp_path):
    inv, ev = fixture_evidence(tmp_path)
    inv["analysis_complete"] = False
    result = m.calculate(inv, ev, tmp_path)
    assert result["tests"]["pct"] is None and result["status"] == "incomplete"


def test_atomic_preserves_edits(tmp_path):
    p = tmp_path / "out.json"
    m.atomic(p, {"a": 1})
    with pytest.raises(m.Invalid):
        m.atomic(p, {"a": 2})
    assert m.read(p) == {"a": 1}


@pytest.mark.parametrize("p", ["../escape", "/absolute"])
def test_path_traversal_rejected(tmp_path, p):
    with pytest.raises(m.Invalid):
        m.under(tmp_path, p)


def test_symlink_escape(tmp_path):
    (tmp_path / "link").symlink_to("/tmp")
    with pytest.raises(m.Invalid):
        m.under(tmp_path, "link/escape")


def test_drift_and_new_source(source):
    inv = m.java_inventory(source)
    assert m.check_drift(inv, source) == []
    (source / "New.java").write_text("class New {}")
    assert m.check_drift(inv, source) == ["New.java"]


def test_data_literals_preserved(source):
    (source / "Data.java").write_text('class Data { void x(){ send("नमस्ते", "", null, 42); } }')
    inv = m.java_inventory(source)
    data = next(u["data"] for u in inv["units"] if u["path"] == "Data.java")
    assert data == ['"नमस्ते"', '""', "null", "42"]


def test_no_implicit_java_compiler_claim():
    help_ = subprocess.run(
        [sys.executable, str(m.BASE / "scripts/migration_tool.py"), "--help"],
        capture_output=True,
        text=True,
        check=True,
    ).stdout
    assert "migrate," not in help_
    for name in [
        "doctor",
        "ingest",
        "inventory",
        "plan",
        "check",
        "validate",
        "metrics",
        "report",
        "resume",
        "benchmark",
        "scaffold",
    ]:
        assert name in help_


def test_mapping_grouping():
    # This sanitized input reproduces quoted Windows paths and shared Java files.
    from pathlib import PureWindowsPath

    rows = [
        ("CORE_DISPLAY_PCR.50", '"C:\\src\\CORE_DISPLAY_PCR_49_50.java"'),
        ("CORE_DISPLAY_PCR.49", "C:\\src\\CORE_DISPLAY_PCR_49_50.java"),
    ]
    groups = {}
    for tc, path in rows:
        groups.setdefault(str(PureWindowsPath(path.strip('"'))), []).append(tc)
    assert len(groups) == 1
    assert sorted(next(iter(groups.values())), key=lambda x: int(x.rsplit(".", 1)[1])) == [
        "CORE_DISPLAY_PCR.49",
        "CORE_DISPLAY_PCR.50",
    ]


def test_template_locator_reuse():
    tree = __import__("ast").parse((m.BASE / "templates/project/src/migrated_automation/login.py").read_text())
    cls = next(n for n in tree.body if isinstance(n, __import__("ast").ClassDef))
    assert cls.name == "LoginPage"
    assert not any(isinstance(n, __import__("ast").Assign) for n in tree.body)
    assert (
        len(
            [
                n
                for n in __import__("ast").walk(cls)
                if isinstance(n, __import__("ast").Call) and __import__("ast").unparse(n.func).startswith("page.get_by")
            ]
        )
        == 4
    )


def test_reporting_options():
    help_ = subprocess.run(
        [sys.executable, "-m", "pytest", "--help"], capture_output=True, text=True, check=True
    ).stdout
    for option in ["--html=", "--alluredir=", "--tracing=", "--screenshot="]:
        assert option in help_


def test_template_import_collection(tmp_path):
    import shutil

    dest = tmp_path / "target"
    shutil.copytree(m.BASE / "templates/project", dest)
    import os

    env = {**os.environ, "PYTHONPATH": str(dest / "src")}
    result = subprocess.run(
        [sys.executable, "-m", "pytest", "tests", "--collect-only", "-q"],
        cwd=dest,
        env=env,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    assert "2 tests collected" in result.stdout


def test_resume_preserves_user_edits_and_invalidates_consumers(source):
    inv = m.java_inventory(source)
    invfile = source / "inventory.json"
    m.atomic(invfile, inv)
    target = source / "target.py"
    target.write_text("value=1")
    cp = {
        "schema_version": 1,
        "snapshot": inv["snapshot"],
        "active_batch": 0,
        "completed_batches": [],
        "remaining_ids": [u["id"] for u in inv["units"]],
        "pending_decisions": [],
        "targets": [{"path": "target.py", "hash": m.sha(target)}],
        "next_task": "review next dependency batch",
        "rule_version": m.VERSION,
        "config_hash": "none",
        "interfaces": [],
        "validation_results": [],
        "stale_artifacts": [],
    }
    m.atomic(source / "checkpoint.json", cp)
    argv = [
        sys.executable,
        str(m.BASE / "scripts/migration_tool.py"),
        "resume",
        "--root",
        str(source),
        "--inventory",
        str(invfile),
        "--checkpoint",
        str(source / "checkpoint.json"),
    ]
    a = subprocess.run(argv + ["--out", str(source / "resume1.json")], capture_output=True, text=True)
    assert a.returncode == 0
    target.write_text("value=2")
    b = subprocess.run(argv + ["--out", str(source / "resume2.json")], capture_output=True, text=True)
    assert b.returncode == 1
    assert m.read(source / "resume2.json")["edited_targets_preserved"] == ["target.py"]
    assert target.read_text() == "value=2"
    (source / "Flow.java").write_text((source / "Flow.java").read_text().replace("return x;", "return x+1;"))
    c = subprocess.run(argv + ["--out", str(source / "resume3.json")], capture_output=True, text=True)
    assert c.returncode == 1
    assert len(m.read(source / "resume3.json")["invalidated_ids"]) == 5


def test_unsupported_boundary_visible(tmp_path):
    (tmp_path / "Legacy.java").write_text("class Legacy { void run(){ new InternetExplorerDriver(); } }")
    assert any(r["reason"] == "InternetExplorerDriver" for r in m.java_inventory(tmp_path)["risks"])


def test_fixture_cleanup_after_failure(tmp_path):
    (tmp_path / "test_lifecycle.py").write_text("""import pytest
from pathlib import Path
@pytest.fixture
def resource():
    yield "resource"
    Path("cleaned").write_text("yes")
def test_failure(resource):
    assert resource == "expected intentional failure"
""")
    r = subprocess.run(
        [sys.executable, "-m", "pytest", "test_lifecycle.py", "-q"], cwd=tmp_path, capture_output=True, text=True
    )
    assert r.returncode == 1
    assert (tmp_path / "cleaned").read_text() == "yes"


def test_contradictory_records_rejected(tmp_path):
    inv, ev = fixture_evidence(tmp_path)
    other = copy.deepcopy(ev["records"][0])
    other["id"] = "failed"
    other["outcome"] = "fail"
    other["commands"][0]["returncode"] = 1
    ev["records"].append(other)
    with pytest.raises(m.Invalid, match="contradictory"):
        m.calculate(inv, ev, tmp_path)


def test_unit_cannot_drop_obligation_links(tmp_path):
    inv, ev = fixture_evidence(tmp_path)
    inv["units"][0]["obligation_ids"] = []
    freeze(inv)
    ev["snapshot"] = inv["snapshot"]
    with pytest.raises(m.Invalid, match="links incomplete"):
        m.calculate(inv, ev, tmp_path)


def test_only_by_factory_is_a_locator(tmp_path):
    (tmp_path / "Names.java").write_text('class Names { void a(){ instance.name(); By.name("user"); } }')
    inv = m.java_inventory(tmp_path)
    assert inv["units"][0]["locators"] == [{"kind": "name", "text": 'By.name("user")'}]


def test_data_provider_dependency(tmp_path):
    (tmp_path / "Provider.java").write_text(
        'class Provider { @Test(dataProvider="rows") void x(String a){} @DataProvider Object[][] rows(){return new Object[][]{{"a"}};} }'
    )
    inv = m.java_inventory(tmp_path)
    unit = next(u for u in inv["units"] if u["signature"] == "x(String)")
    assert len(unit["dependencies"]) == 1 and unit["dependencies"][0].endswith("rows()")


def test_legacy_profile_blocks_application_execution(tmp_path):
    cfg = {
        "schema_version": 1,
        "source_roots": [str(tmp_path)],
        "target_root": str(tmp_path / "target"),
        "api_mode": "sync",
        "profile": "legacy-bulk",
        "allow_customer_execution": False,
        "browser_matrix": ["chromium"],
        "batch_size": 4,
        "token_budget_estimate": 8000,
    }
    m.atomic(tmp_path / "config.json", cfg)
    m.atomic(tmp_path / "commands.json", [[sys.executable, "-m", "pytest", "tests"]])
    r = subprocess.run(
        [
            sys.executable,
            str(m.BASE / "scripts/migration_tool.py"),
            "validate",
            "--root",
            str(tmp_path),
            "--commands",
            str(tmp_path / "commands.json"),
            "--config",
            str(tmp_path / "config.json"),
            "--out",
            str(tmp_path / "out.json"),
        ],
        capture_output=True,
        text=True,
    )
    assert r.returncode == 2
    assert "collection only" in r.stderr
