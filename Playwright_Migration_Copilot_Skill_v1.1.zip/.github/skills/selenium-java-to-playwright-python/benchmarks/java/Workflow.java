package fixture;
import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
class Workflow {
    WebDriver driver;
    @Test void login() {
        driver.findElement(By.xpath("//input[@id='user']")).sendKeys("demo");
        driver.findElement(By.id("password")).sendKeys("valid");
        driver.findElement(By.id("login")).click();
        Assert.assertEquals(driver.findElement(By.id("status")).getText(), "Welcome demo");
    }
    @Test(dataProvider="rows") void variants(String value) { Assert.assertNotNull(value); }
    @DataProvider Object[][] rows() { return new Object[][]{{""},{"नमस्ते"}}; }
}
