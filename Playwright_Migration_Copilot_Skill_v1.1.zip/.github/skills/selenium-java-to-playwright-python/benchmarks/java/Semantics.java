import java.math.BigDecimal;
import java.math.RoundingMode;
public class Semantics {
    static class Base {
        String label;
        Base() { label = "base"; }
        String name() { return label; }
    }
    static class Child extends Base {
        Child() { super(); label += ":child"; }
        @Override String name() { return super.name() + ":override"; }
    }
    static String lookup(int value) { return "id:" + value; }
    static String lookup(String value) { return "name:" + value; }
    static String lookup(String value, int count) { return lookup(value) + ":" + count; }
    static int divide(int a, int b) { return a / b; }
    public static void main(String[] args) {
        System.out.println(new Child().name());
        System.out.println(lookup(7));
        System.out.println(lookup("7"));
        System.out.println(lookup("", 2));
        System.out.println(divide(-7, 3));
        System.out.println(divide(Integer.MIN_VALUE, -1));
        System.out.println(lookup((String)null));
        System.out.println(lookup((String)null, 2));
        System.out.println(new BigDecimal("2.345").setScale(2, RoundingMode.HALF_UP));
    }
}
