import java.time.ZonedDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
public class UtilityContracts {
    static String config(String property, String env, String fallback) {
        return property != null ? property : env != null ? env : fallback;
    }
    static class SoftChecks {
        final List<String> failures = new ArrayList<>();
        void check(boolean condition, String message) { if (!condition) failures.add(message); }
        void assertAll() { if (!failures.isEmpty()) throw new AssertionError(String.join("|", failures)); }
    }
    public static void main(String[] args) {
        System.out.println(ZonedDateTime.parse("2026-10-22T10:00:00+05:30[Asia/Kolkata]").withZoneSameInstant(ZoneId.of("UTC")).toInstant());
        System.out.println("a12b34".replaceAll("(\\d+)", "[$1]"));
        System.out.println(config("", "env", "default"));
        System.out.println(config(null, "env", "default"));
        System.out.println(config(null, null, "default"));
        SoftChecks checks = new SoftChecks();
        checks.check(false, "first"); checks.check(true, "second"); checks.check(false, "third");
        try { checks.assertAll(); } catch (AssertionError e) { System.out.println(e.getMessage()); }
    }
}
