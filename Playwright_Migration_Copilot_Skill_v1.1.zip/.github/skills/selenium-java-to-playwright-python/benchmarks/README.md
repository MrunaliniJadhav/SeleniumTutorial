# Benchmark execution and boundaries

From the skill folder, with the dependencies installed:

```bash
python -m pytest tests benchmarks/python -q --junitxml=results.xml
```

The browser fixture starts a local ephemeral HTTP server and resets each default page/context per test. It uses synthetic data only. Helpers execute Java with the Java 17 source-file launcher and compare fixed output vectors to Python. Chromium is the exercised browser. Additional browser/OS and parallel runs are explicit validation work, not assumed.

The `Workflow.java` file is a parser fixture, not a compiled customer source. It includes a dynamic TestNG provider so unknown discovery remains visible. `Semantics.java` is a real executable JVM helper baseline. Neither constitutes a Selenium browser run.

## Optional original Selenium browser baseline

The `selenium-baseline` Maven example provides a real Java Selenium login/negative flow against the same HTML. It has not been compiled or executed here because Maven/ChromeDriver baseline dependencies are unavailable. Install Maven, Selenium dependencies and a Chrome/ChromeDriver pair compatible with your environment before claiming this level.

From `benchmarks/web` run `python -m http.server 8765 --bind 127.0.0.1`. From `benchmarks/selenium-baseline` run:

```bash
mvn compile dependency:copy-dependencies
java -cp "target/classes:target/dependency/*" SeleniumBaseline http://127.0.0.1:8765/index.html
```

On Windows use `;` instead of `:` in the classpath. Set CHROME_BINARY only if selecting a known local Chrome binary. The expected tab-separated lines are `valid\tWelcome demo` and `negative\tInvalid credentials`. Collect those source outcomes and compare to Playwright test_form valid/negative on identical controlled state. Selenium Manager may need network access to provision a driver; no provisioning success is claimed.

## Coverage that remains incomplete

No actual customer browser run, Java Selenium baseline, full source framework lifecycle/listener/report integration, parallel worker/account isolation, full browser matrix, actual GitHub Actions run, Allure CLI HTML generation, generic Java type resolution, or Copilot host token comparison is verified. Synthetic JVM differential vectors also cover soft assertion aggregation, configuration precedence, timezone conversion and regex replacement. Source-specific contracts still require actual source review. Current benchmark coverage is evidence for specific tested rules, not a universal migration accuracy estimate.
