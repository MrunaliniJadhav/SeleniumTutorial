import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
public class SeleniumBaseline {
    public static void main(String[] args) {
        if (args.length != 1 || !args[0].startsWith("http://127.0.0.1:")) {
            throw new IllegalArgumentException("Supply the local synthetic fixture URL only");
        }
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless=new", "--no-sandbox");
        String binary = System.getenv("CHROME_BINARY");
        if (binary != null && !binary.isBlank()) options.setBinary(binary);
        WebDriver driver = new ChromeDriver(options);
        try {
            driver.get(args[0]);
            driver.findElement(By.id("user")).sendKeys("demo");
            driver.findElement(By.id("password")).sendKeys("valid");
            driver.findElement(By.id("login")).click();
            new WebDriverWait(driver, Duration.ofSeconds(5)).until(d -> d.findElement(By.id("status")).getText().equals("Welcome demo"));
            System.out.println("valid\tWelcome demo");
            driver.findElement(By.id("password")).clear();
            driver.findElement(By.id("password")).sendKeys("wrong");
            driver.findElement(By.id("login")).click();
            new WebDriverWait(driver, Duration.ofSeconds(5)).until(d -> d.findElement(By.id("status")).getText().equals("Invalid credentials"));
            System.out.println("negative\tInvalid credentials");
        } finally {
            driver.quit();
        }
    }
}
