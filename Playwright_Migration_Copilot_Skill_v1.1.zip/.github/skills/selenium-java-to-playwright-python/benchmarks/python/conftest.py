from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import threading
import pytest


@pytest.fixture(scope="session")
def fixture_url():
    body = (Path(__file__).parents[1] / "web/index.html").read_bytes()

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            routes = {
                "/outer": b'<iframe title="Inner frame" src="/inner"></iframe>',
                "/inner": b"<label>Frame input<input></label>",
                "/popup": b"<h1>Popup</h1>",
                "/api/data": b'{"value":"server"}',
                "/download": b"fixture download",
            }
            self.send_response(200)
            self.send_header(
                "Content-Type",
                "application/json"
                if self.path == "/api/data"
                else "application/octet-stream"
                if self.path == "/download"
                else "text/html; charset=utf-8",
            )
            self.end_headers()
            self.wfile.write(routes.get(self.path, body))

        def log_message(self, *_args):
            return None

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{server.server_port}"
    server.shutdown()
    server.server_close()
    thread.join()


@pytest.fixture
def app(page, fixture_url):
    page.goto(fixture_url)
    return page
