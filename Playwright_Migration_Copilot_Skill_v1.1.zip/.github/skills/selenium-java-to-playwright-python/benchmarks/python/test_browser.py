import pytest
from playwright.sync_api import expect

pytestmark = pytest.mark.browser


@pytest.mark.parametrize(
    "user,password,expected",
    [
        ("demo", "valid", "Welcome demo"),
        ("demo", "wrong", "Invalid credentials"),
        ("", "", "Invalid credentials"),
        ("नमस्ते", "valid", "Invalid credentials"),
    ],
    ids=["valid", "negative", "empty", "unicode"],
)
def test_form(app, user, password, expected):
    app.get_by_label("Username", exact=True).fill(user)
    app.get_by_label("Password", exact=True).fill(password)
    app.get_by_role("button", name="Sign in", exact=True).click()
    expect(app.get_by_role("status")).to_have_text(expected)


def test_xpath_and_rerender(app):
    app.locator("xpath=//input[@id='user']").fill("same data")
    expect(app.get_by_label("Username", exact=True)).to_have_value("same data")
    items = app.locator("#list li")
    app.get_by_role("button", name="Load list").click()
    expect(items).to_have_text(["A", "B"])
    app.get_by_role("button", name="Load list").click()
    expect(items).to_have_text(["A", "B"])


def test_scoping_widgets_and_properties(app):
    app.get_by_role("region", name="Orders").get_by_role("button", name="Save", exact=True).click()
    expect(app.get_by_role("region", name="Orders").locator("p")).to_have_text("Order saved")
    app.get_by_label("Size").select_option(value="l")
    expect(app.get_by_label("Size")).to_have_value("l")
    app.get_by_label("Accept").check()
    expect(app.get_by_label("Accept")).to_be_checked()
    app.get_by_label("One", exact=True).check()
    expect(app.get_by_label("One", exact=True)).to_be_checked()
    app.get_by_role("button", name="Choose color").click()
    app.get_by_role("option", name="Blue").click()
    expect(app.locator("#menu")).to_have_text("Blue")
    app.get_by_label("Value", exact=True).press("ControlOrMeta+A")
    app.get_by_label("Value", exact=True).press("7")
    expect(app.get_by_label("Value", exact=True)).to_have_value("7")
    expect(app.locator("#exact")).to_have_text("Alpha Beta")
    expect(app.locator("#hidden")).to_be_hidden()
    expect(app.locator("#missing")).to_have_count(0)
    app.locator("#hover").hover()
    expect(app.locator("#hover")).to_have_text("Hovered")


def test_frames_shadow_and_events(app, tmp_path):
    field = (
        app.frame_locator('iframe[title="Outer frame"]')
        .frame_locator('iframe[title="Inner frame"]')
        .get_by_label("Frame input")
    )
    field.fill("nested")
    expect(field).to_have_value("nested")
    expect(app.get_by_role("button", name="Shadow button")).to_be_visible()
    app.once("dialog", lambda dialog: dialog.accept("42"))
    app.get_by_role("button", name="Prompt", exact=True).click()
    expect(app.locator("#answer")).to_have_text("42")
    with app.expect_popup() as event:
        app.get_by_role("button", name="Open tab").click()
    popup = event.value
    expect(popup.get_by_role("heading")).to_have_text("Popup")
    popup.close()
    upload = tmp_path / "input.txt"
    upload.write_text("input")
    app.get_by_label("Attachment").set_input_files(upload)
    expect(app.locator("#filename")).to_have_text("input.txt")
    with app.expect_download() as event:
        app.get_by_role("link", name="Download", exact=True).click()
    output = tmp_path / event.value.suggested_filename
    event.value.save_as(output)
    assert output.read_text() == "fixture download"


def test_network_and_spa(app):
    # Explicit mocked integration boundary, separate from real-server case below.
    app.route("**/api/data", lambda route: route.fulfill(json={"value": "mocked"}))
    with app.expect_response("**/api/data") as response:
        app.get_by_role("button", name="Fetch", exact=True).click()
    assert response.value.ok
    expect(app.locator("#result")).to_have_text("mocked")
    expect(app).to_have_url(__import__("re").compile("/ready$"))


def test_real_network_and_context_isolation(browser, app, fixture_url):
    # Custom contexts explicitly manage their options and cleanup; plugin diagnostics do not apply.
    app.evaluate("localStorage.setItem('tenant','one')")
    state = app.context.storage_state()
    context = browser.new_context(storage_state=state)
    other = browser.new_context()
    try:
        p = context.new_page()
        p.goto(fixture_url)
        assert p.evaluate("localStorage.getItem('tenant')") == "one"
        q = other.new_page()
        q.goto(fixture_url)
        assert q.evaluate("localStorage.getItem('tenant')") is None
        with q.expect_response("**/api/data") as response:
            q.get_by_role("button", name="Fetch", exact=True).click()
        assert response.value.ok
        expect(q.locator("#result")).to_have_text("server")
    finally:
        context.close()
        other.close()
