from decimal import Decimal, ROUND_HALF_UP
from typing import overload


class Base:
    def __init__(self):
        self.label = "base"

    def name(self):
        return self.label


class Child(Base):
    def __init__(self):
        super().__init__()
        self.label += ":child"

    def name(self):
        return super().name() + ":override"


_MISSING = object()


@overload
def lookup(value: int) -> str: ...
@overload
def lookup(value: str | None, count: int = ...) -> str: ...
def lookup(value, count=_MISSING):
    if type(value) is int and count is _MISSING:
        return f"id:{value}"
    if type(value) is str or value is None:
        text = "null" if value is None else value
        if count is _MISSING:
            return "name:" + text
        if type(count) is int:
            return f"name:{text}:{count}"
    raise TypeError("Unsupported Java overload contract")


def divide(a, b):
    # Integer arithmetic avoids float precision and Python floor-division mismatch.
    if (
        type(a) is not int
        or type(b) is not int
        or not (-2147483648 <= a <= 2147483647 and -2147483648 <= b <= 2147483647)
    ):
        raise ValueError("Java int contract requires signed 32-bit integers")
    if a == -2147483648 and b == -1:
        return -2147483648
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return (abs(a) // abs(b)) * (-1 if (a < 0) != (b < 0) else 1)


def vectors():
    return [
        Child().name(),
        lookup(7),
        lookup("7"),
        lookup("", 2),
        str(divide(-7, 3)),
        str(divide(-2147483648, -1)),
        lookup(None),
        lookup(None, 2),
        str(Decimal("2.345").quantize(Decimal(".01"), rounding=ROUND_HALF_UP)),
    ]
