from pathlib import Path
import subprocess
import pytest
from semantics import Child, divide, lookup, vectors

EXPECTED = ["base:child:override", "id:7", "name:7", "name::2", "-2", "-2147483648", "name:null", "name:null:2", "2.35"]


def test_java_python_differential(tmp_path):
    source = Path(__file__).parents[1] / "java/Semantics.java"
    result = subprocess.run(["java", str(source)], check=True, capture_output=True, text=True)
    assert result.stdout.splitlines() == EXPECTED == vectors()


def test_override_and_super():
    assert Child().name() == "base:child:override"


@pytest.mark.parametrize("value,count", [(True, 1), (1, 2), ("x", True)])
def test_reject_ambiguous_overloads(value, count):
    with pytest.raises(TypeError):
        lookup(value, count)


@pytest.mark.heldout
@pytest.mark.parametrize("a,b,expected", [(7, -3, -2), (-7, -3, 2), (0, 3, 0), (-2147483648, -1, -2147483648)])
def test_heldout_integer_vectors(a, b, expected):
    assert divide(a, b) == expected


def test_expected_exception():
    with pytest.raises(ZeroDivisionError, match="division by zero"):
        divide(1, 0)


def test_null_string_overload_contract():
    assert lookup(None) == "name:null"
    assert lookup(None, 2) == "name:null:2"


def test_int_domain_rejects_non_java_values():
    with pytest.raises(ValueError, match="signed 32-bit"):
        divide(9007199254740995, 3)
