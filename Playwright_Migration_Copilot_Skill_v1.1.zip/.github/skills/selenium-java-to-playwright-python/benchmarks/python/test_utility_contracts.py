from datetime import datetime, timezone
from pathlib import Path
import re
import subprocess
import pytest


class SoftChecks:
    def __init__(self):
        self.failures = []

    def check(self, condition, message):
        if not condition:
            self.failures.append(message)

    def assert_all(self):
        if self.failures:
            raise AssertionError("|".join(self.failures))


def config(property_value, env_value, fallback):
    if property_value is not None:
        return property_value
    if env_value is not None:
        return env_value
    return fallback


def test_jvm_timezone_regex_config_soft_assertions():
    java = Path(__file__).parents[1] / "java/UtilityContracts.java"
    result = subprocess.run(["java", str(java)], capture_output=True, text=True, check=True)
    independent_expected = ["2026-10-22T04:30:00Z", "a[12]b[34]", "", "env", "default", "first|third"]
    checks = SoftChecks()
    checks.check(False, "first")
    checks.check(True, "second")
    checks.check(False, "third")
    with pytest.raises(AssertionError) as failure:
        checks.assert_all()
    target = [
        datetime.fromisoformat("2026-10-22T10:00:00+05:30").astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
        re.sub(r"(\d+)", r"[\1]", "a12b34"),
        config("", "env", "default"),
        config(None, "env", "default"),
        config(None, None, "default"),
        str(failure.value),
    ]
    assert result.stdout.splitlines() == independent_expected == target


def test_soft_assertions_success_and_retained_failures():
    checks = SoftChecks()
    checks.check(True, "success")
    assert checks.assert_all() is None
    checks.check(False, "not swallowed")
    with pytest.raises(AssertionError, match="not swallowed"):
        checks.assert_all()
