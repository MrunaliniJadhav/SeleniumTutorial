# Before/after examples

Each example has a named contract and executed validation; examples are synthetic and independent of customer API names.

| Java/source pattern | Python target | Preserved contract and check |
| --- | --- | --- |
| benchmarks/java/Workflow.java login XPath, WebDriver calls and exact assertion | templates/project/src/migrated_automation/login.py plus tests/test_login.py | Native locator composition, sign-in sequence, exact positive/negative outcome; generated target runtime tests |
| By.xpath original locator | benchmarks/python/test_browser.py::test_xpath_and_rerender | Exact input identity/value and DOM rerender; supported XPath retained |
| Thread.sleep/wait_for_timeout | delayed fixture + expect list text | Delayed list readiness without arbitrary target waits; broken-wait detector regression |
| Semantics.java Base/Child | benchmarks/python/semantics.py Base/Child | Constructor order, super and polymorphic dispatch; real JVM differential |
| Semantics.java lookup(int), lookup(String), lookup(String,int) | lookup with typing.overload and one concrete implementation | All arities/type contracts, nullable String and bool/int distinction; JVM differential plus invalid-input tests |
| TestNG provider in Workflow.java | stable pytest.param IDs in template/test_form | Existing known data variants must be retained; unknown Java dynamic case count remains blocked until source discovery |
| Driver lifecycle/state | pytest-managed page/context and explicit custom contexts in test_browser.py | Per-test isolation and explicit state reuse; separate context cleanup; no cross-worker claim |
| Java helper integer division/BigDecimal | divide and Decimal ROUND_HALF_UP | Negative quotient, signed 32-bit boundary, explicit decimal rounding; JVM differential and held-out vectors |
| Shared source mapping 49/50 | project_evidence/mapping_groups.json outside skill | Both manual IDs retained in one planned file; actual customer implementation blocked |

The template is the executable PageFactory redesign pattern: replace cached WebElements with owning-page locator definitions. Do not invent a literal source PageFactory implementation that was not supplied. For actual migration, read its annotations/wrapper contracts and preserve behavior before replacing its structure.
