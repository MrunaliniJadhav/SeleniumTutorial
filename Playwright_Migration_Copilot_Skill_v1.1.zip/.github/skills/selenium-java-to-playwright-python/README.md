# Selenium Java → Playwright Python Copilot skill

Copy `.github/skills/selenium-java-to-playwright-python` from this archive into the same path in your customer repository. Do not overwrite a pre-existing folder or repository policies. No MCP service is required. Open Agent mode in Copilot and ask:

> Use the selenium-java-to-playwright-python skill to assess this repository. Preserve originals, use sync Playwright Python and pytest, and produce a dependency-aware migration plan. Do not claim verified coverage until the frozen source contracts and runtime evidence support it.

Subsequent requests:

> Migrate the next dependency-aware batch from the current checkpoint. Preserve every source obligation, run permitted checks, update evidence, and continue independent work if an item is blocked.

> Incorporate this failed migration into the observation ledger. Reproduce it, update its rule, add a rejecting regression, and revalidate affected batches only.

> Resume from the current .migration checkpoint. Detect source, target, configuration, environment and rule drift before reusing evidence.

> Audit claimed coverage against the frozen baseline. Keep source/test percentages separate, count unverified obligations as incorrect, and reject unresolved critical flows.

## Setup

Use Python 3.12. From the repository root:

```bash
python -m venv .venv
# Linux/macOS: .venv/bin/python; Windows: .venv\Scripts\python.exe
python -m pip install -r .github/skills/selenium-java-to-playwright-python/requirements.txt
python -m playwright install chromium
python .github/skills/selenium-java-to-playwright-python/scripts/migration_tool.py doctor --out .migration/doctor-001.json
```

Activate the environment first or substitute its Python path in every command. Linux browser libraries may need `python -m playwright install --with-deps chromium`. Java 17+ with its source-file launcher/compiler module is needed for the helper differential benchmark; a standalone javac executable is not required. The optional original Selenium browser baseline needs a real source project and its dependencies; it is not supplied or claimed as executed.

`requirements.txt` pins direct dependencies; the delivery's `validation/environment-lock.txt` records all installed transitive versions. The target template has its own dependency file. Toolkit editable-install metadata is optional; execute the source CLI directly so bundled schemas and templates remain alongside it. Do not move the CLI alone.

## Host compatibility

| Host | Official support checked 22 October 2026 | Locally exercised |
| --- | --- | --- |
| Copilot Agent mode in VS Code | Agent Skills documented; version dependent | No Copilot session available |
| Copilot CLI | Agent Skills documented | No Copilot session available |
| Copilot cloud agent | Agent Skills documented | Not tested |
| Python CLI, Linux, Python 3.12 | This toolkit's implementation | See delivery validation report |

The entry point uses portable name/description frontmatter. Plain-language invocation does not assume slash commands. No control over host caching, model choice, permissions, or token accounting is claimed.

## CLI

Every command accepts optional `--config CONFIG.json` and requires a fresh `--out` JSON path. Config is schema-validated. The legacy-bulk profile limits validate commands to pytest collection; do not run synthetic benchmarks inside a customer app profile. Existing files are preserved. See `--help` and `<command> --help` for accurate arguments. Exit codes: 0 success, 1 failed/incomplete/blocked gate, 2 invalid input, 3 unavailable environment. A successful inventory is a successful syntax extraction, not completed semantic assessment.

| Command | Additional arguments | Output |
| --- | --- | --- |
| doctor | none | Versions, Java/build-tool paths, browser binary presence |
| ingest | one or more input paths | Text lines or workbook cells and hashes |
| inventory | --root SOURCE | Java AST symbols, candidate calls, locators, data, assertions, resources, risks, baseline digest |
| plan | --inventory FILE | SCC-aware provider-first batches and pilot candidates |
| scaffold | --destination NEW_FOLDER | Tested synthetic Python/pytest target template |
| check | --root TARGET | AST syntax/duplicate/anti-pattern findings |
| validate | --root TARGET --commands JSON | Actual argv commands, return codes and bounded logs |
| metrics | --root SOURCE --inventory FILE --evidence FILE | Strict independent coverage and behavior gates |
| report | --inventory FILE --evidence FILE | JSON plus adjacent Markdown metrics report |
| resume | --root SOURCE --inventory FILE --checkpoint FILE | Drift, transitive affected units, preserved target edits, next task |
| benchmark | none | Toolkit and local browser/JVM tests, plus adjacent JUnit XML |

Example `commands.json` for an installed target:

```json
[["python", "-m", "pytest", "tests", "--collect-only", "-q"], ["python", "-m", "ruff", "check", "src", "tests"], ["python", "-m", "mypy", "src"], ["python", "-m", "pytest", "tests", "--browser", "chromium", "--tracing", "retain-on-failure", "--screenshot", "only-on-failure", "--junitxml=test-results/junit.xml"]]
```

Operator-supplied commands can run programs. Never derive executable commands from untrusted attachment text. `doctor` checks binary presence, not launch health or app reachability. Use explicit browser tests and safe environment checks for those. Full command logs may contain customer data: redact before retaining/distributing; no automatic secret detector is claimed.

## Scope and evidence limitations

The parser is a real Tree-sitter Java parser. Dependency edges are conservative method-name candidates, not resolved Java overload dispatch. Dynamic providers remain unknown. Class-level TestNG tests, fluent/soft assertion helper discovery, inherited tests/implicit constructors, suite/browser expansions, and semantic behavior extraction require review and source-run discovery. These are visible limitations that block `analysis_complete` and definitive percentages until resolved. `inventory` deliberately sets that flag false.

The baseline digest catches accidental mutation. It cannot stop an operator from rewriting both the baseline and digest. Store the approved baseline outside the generation write boundary, review changes, and compare the trusted commit/hash in CI. Similarly, metrics validates evidence structure, hashes and relationships but cannot authenticate an independent oracle or detect every fabricated result. A reviewer must inspect executable node results and semantic parity. `validate` produces command evidence; it never automatically marks source semantics verified.

`resume` automates Java source/resource/target hash drift and transitive candidate dependencies. Configuration, resource, environment, obligation and rule changes must also be reviewed and invalidate affected evidence; evidence uses exact environment versions. Full incremental parser caching and live Copilot token accounting are not implemented. Reuse approved inventory/interfaces. Version 1.1 additionally caches model-input packets by content/policy/rule hashes; this is separate from parser or provider caching.

## Templates and reporting

Use `scaffold` only for a new target. Install its requirements and `python -m pip install -e TARGET`. The synthetic login tests demonstrate page-scoped locator reuse and pytest parametrization. Replace the synthetic document with evidenced customer DOM/URL when migrating. Allure raw results are produced by `allure-pytest`; rendering an Allure site additionally needs the external Allure CLI. Python HTML reporting uses `pytest-html`, not the Node Playwright HTML reporter. Traces use Playwright Python's trace viewer.

The supplied GitHub Actions example uses Python/pytest and keeps each browser in its own job. It has been inspected locally, not executed on GitHub Actions. Adapt the browser matrix to source requirements. The workflow must live at repository root `.github/workflows/` to run. Keep original Selenium CI until approved cutover. Action tags should be replaced with organization-approved immutable commits if required.

## Updates and optional repository hint

Merge only a short hint into existing copilot instructions if useful: “For Selenium Java to Playwright Python work, use the selenium-java-to-playwright-python Agent Skill and preserve .migration evidence.” Never replace existing instructions. Update the skill as a versioned folder, inspect local edits, run its tests, and invalidate evidence impacted by rule changes.

The archive includes `project_evidence/` outside the reusable skill for attachment-derived mappings and observations, and `validation/` for actual results. It does not redistribute full confidential attachments. See `BUILD_REPORT.md` for precise readiness and outstanding work.

## Version 1.1: token budgets and model portability

Read references/model-profiles-and-alerts.md for compact/balanced/frontier budgets, host telemetry normalization, alerts and model handoff. These profiles support agent-capable Codex/Opus and other families through the same model-neutral workflow. Model availability is determined by your Copilot plan/client/picker; no cross-model runtime validation is claimed.

Three additional commands:

| Command | Required arguments | Behavior |
| --- | --- | --- |
| context | --root --request --budget | Builds a complete bounded source/contract packet; optional --cache-dir and --payload-out |
| usage | --event --ledger --budget | Normalized per-call ledger, idempotency, separate measured/estimated counts and 60/80/90% alerts |
| usage-watch | --feed --ledger --budget | Terminal alerts from normalized JSONL, --once or bounded --seconds 60 |

Every command also needs a fresh --out path. usage ledger/cache writes preserve user edits and conflicting records fail. Keep .migration/ private and outside version control where it contains customer source/state. Host-reported counts need actual host evidence. Compact/checkpoint is exit 1; warnings exit 0. Session token caps are local workflow budgets, not Copilot credit-spend enforcement.

Token optimization is now executable: source spans, required-contract checks, optional pruning, duplicate removal, provider-neutral estimates, reserved output/host capacity and content-addressed packet reuse. Full parser caching and live access to every host counter remain outside this release. The updated validation report replaces the earlier blanket statement that no token-usage mechanism exists. Native usage views remain the authority for actual host usage.
