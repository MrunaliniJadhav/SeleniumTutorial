# Copilot Playwright migration skill v1.1

Start with BUILD_REPORT.md for measured results and limitations. Install the `.github/skills/selenium-java-to-playwright-python` folder at the same location in your repository. See its README and references/model-profiles-and-alerts.md for token budgets, model profiles and alerts.

The current validation run passes 120 tests. Live Copilot counters/model behavior and customer migration percentages are not claimed. `project_evidence` retains original attachment findings and blocked customer mappings. `validation/token-smoke` contains the current executable token-budget examples. `validation/v1_0` retains historical migration/template checks.

Ask Copilot: “Use the selenium-java-to-playwright-python skill with the compact profile. Build a complete bounded packet, report token warnings at 60/80/90%, preserve all source obligations, and validate one migration slice before continuing.”
