# Migration evidence report

```json
{
  "schema_version": 1,
  "status": "incomplete",
  "gates": {
    "complete_inventory": false,
    "test_coverage": false,
    "source_coverage": false,
    "behavior_accuracy": false,
    "critical": true,
    "assertions": true,
    "no_hidden_skips": true,
    "mandatory_checks": false
  },
  "tests": {
    "verified": 0,
    "total": 2,
    "pct": null
  },
  "source": {
    "verified": 0,
    "total": 12,
    "pct": null
  },
  "behavior": {
    "P": 0,
    "F": 0,
    "X": 0,
    "pct": null
  },
  "denominator_status": "INDETERMINATE",
  "automation_pct": "UNMEASURED",
  "note": "Evidence needs independent review; this tool cannot authenticate an oracle or prove arbitrary semantic equivalence."
}
```
