# Benchmark coverage

| Category | Executed test / implementation | Status |
| --- | --- | --- |
| Form workflow/negative login | test_browser.py::test_form | passed |
| Override, initialization, super | test_semantics.py::test_override_and_super; JVM differential | passed |
| Overloads, arities, types, bool/int, None | test_semantics.py::test_reject_ambiguous_overloads; test_null_string_overload_contract | passed; constructor factory alternatives not generalized |
| typing.overload/duplicate methods | test_typing_overload_is_allowed; test_broken_migrations_detected | passed |
| Delayed render/rerender/collection | test_xpath_and_rerender | passed |
| Duplicate text/strictness | test_scoping_widgets_and_properties; positional/force negative fixtures | passed |
| Exact text/hidden/detached/value | test_scoping_widgets_and_properties | passed |
| Native/custom select/check/radio/key/hover | test_scoping_widgets_and_properties | passed |
| Nested iframe/open shadow | test_frames_shadow_and_events | passed |
| Popup/dialog/upload/download | test_frames_shadow_and_events | passed |
| SPA/network events | test_network_and_spa; real network check | passed |
| State reuse/context isolation | test_real_network_and_context_isolation | passed for local storage; authenticated users/tenants/parallel workers unverified |
| Parametrized empty/Unicode/dynamic uncertainty | test_form; test_inventory_overloads_and_dynamic; test_data_literals_preserved | passed; actual provider expansion requires source-run discovery |
| Lifecycle/exception/cleanup after failure | test_fixture_cleanup_after_failure; test_expected_exception | passed for synthetic lifecycle; full TestNG listener integrations unverified |
| Soft assertion aggregation | test_utility_contracts.py JVM differential | passed for synthetic aggregator; customer-specific adapter requires actual contract |
| Utility division/decimal | JVM differential plus held-out arithmetic vectors | passed; timezone/regex/config precedence verified by UtilityContracts.java differential vectors |
| API setup/mock boundary | test_network_and_spa; real-network counterpart | passed |
| Unsupported legacy browser detection | test_unsupported_boundary_visible | passed; capability adapters unavailable |
| Resume/drift/user edits | test_resume_preserves_user_edits_and_invalidates_consumers; atomic/path tests | passed for implemented Java/resource/target checks; full incremental cache not implemented |
| Metrics anti-gaming | test_exact_threshold_fails; test_evidence_fraud_rejected; incomplete/critical/assertion tests | passed; trusted baseline and independent evidence review still required |
| Attachment regressions | observations.json and rule_regression_map.json | synthetic checks passed; customer-specific closure blocked where marked |
