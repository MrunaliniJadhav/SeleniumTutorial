# Compact packet and alert workflow assessment

Prepared one reviewed helper task, `Semantics.java::Semantics.divide(int,int)`, without changing the skill or running a full benchmark. The exact source line and contract obligations are in ready input-001.json. The helper has no callable dependencies, fields, DOM or side effects. Obligations retain signed 32-bit inputs, truncation toward zero, minimum-int overflow and zero-divisor error behavior. The packet requests independent JVM vectors before any equivalence claim.

All commands used `/workspace/scratch/6b63bc160867/.venv/bin/python -B` and the updated skill's `scripts/migration_tool.py`. Full argv and captured results are in commands-and-results.json.

| Exercise | Actual result | Exit |
| --- | --- | --- |
| context, compact profile | ready; estimated 697/4,000 input tokens (17.42%); output reserve 1,000; host/history reserve 4,000 | 0 |
| same context request/cache | ready; cache_hit=true; same content key and 697 estimate | 0 |
| dependencies_complete=false | blocked; no blocked-input.json emitted | 1 |
| usage, synthetic estimated total 600/1,000 | TOKEN WARNING; reduce optional context | 0 |
| usage, synthetic estimated total 800/1,000 | TOKEN CHECKPOINT; checkpoint then compact/new chat | 1 |
| usage, synthetic estimated total 900/1,000 | TOKEN STOP; start no new model work in that synthetic session | 1 |
| replay third event | idempotent_replay=true; still 3 events and 900 total | 1 |
| usage-watch --once on four JSONL rows including replay | 3 events seen, 3 threshold alerts emitted, final blocked | 1 |

The context command deduplicated the repeated obligation fragment, preserved its required status and contract ID, and omitted the oversized optional synthetic log with an explicit reason. No required material was pruned. The blocked dependency packet was inspected only as an audit result; it was not loaded as a migration task. Only the ready input file was read as task payload.

The usage fixtures are explicitly synthetic estimated counts. They do not describe this conversation, actual Copilot/model consumption, remaining entitlement or spend. No host-reported events were supplied. Every usage result retains current context usage and window as null/unknown; cumulative session totals are not treated as context occupancy. The synthetic STOP was a test outcome, not evidence that this actual conversation exhausted a model window.

No Copilot picker session was available. The model label therefore explicitly says UNKNOWN, and the configured context window is null. Compact/balanced/frontier are workload profiles, not advertised model limits or evidence that any Codex/Opus variant is available or compatible. This test verifies deterministic local packet/ledger behavior, not comparative model quality, actual Agent Skills discovery or Copilot runtime integration. No actual model switching or customer migration execution was performed.

The byte estimator is a planning proxy rather than an exact provider tokenizer or guaranteed upper bound. The local content cache hit proves packet reuse only, not provider cache billing savings. The watcher needs normalized JSONL from an operator/export adapter; it is not an IDE popup, native Copilot-log parser, hidden-counter integration or mechanism that intercepts all model calls. Local session limits do not enforce credits or billing. The CLI does not authenticate telemetry provenance labels. Model choice, tool support and host window still need verification in the actual client.

No new blocker or bug was encountered in this bounded workflow. The packet is ready for one helper's migration work; it does not claim implementation, execution equivalence or customer target achievement.
