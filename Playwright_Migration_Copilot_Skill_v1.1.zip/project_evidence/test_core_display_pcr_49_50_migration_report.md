# Planned migration: CORE_DISPLAY_PCR.49, CORE_DISPLAY_PCR.50

Selenium reference: `C:\AMAT_Automation\mainline_seleniumcoreplus\src\test\java\com\scripts\CreateProjectAndPCR_Display\CORE_DISPLAY_PCR_49_50.java`

Proposed target: `test_core_display_pcr_49_50.py`

Status: BLOCKED. Source implementation, manual steps and canonical target are not supplied. No executable target was invented.

| Manual ID | Step | Selenium call | Python equivalent | Status | Recommendation |
| --- | --- | --- | --- | --- | --- |
| CORE_DISPLAY_PCR.49 | Unknown | Source not supplied | Target framework not supplied | Missing evidence | Supply source/manual/canonical files; preserve exact TestCaseID data. |
| CORE_DISPLAY_PCR.50 | Unknown | Source not supplied | Target framework not supplied | Missing evidence | Supply source/manual/canonical files; preserve exact TestCaseID data. |

Selenium versus manual deviations: unknown until both inputs are read.

Recommended new functions: not assessable without implementations. No helpers were created in the customer framework.
