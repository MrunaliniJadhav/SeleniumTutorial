# Attachment findings

Four attachments were decoded. No customer Java repository, manual step workbook, canonical Python reference or application environment was supplied. Historical Windows paths are references, not accessible directories.

## Mapping groups

- CORE_DISPLAY_PCR.52 → CORE_DISPLAY_PCR_52.java → test_core_display_pcr_52.py
- CORE_DISPLAY_PCR.51 → CORE_DISPLAY_PCR_51.java → test_core_display_pcr_51.py
- CORE_DISPLAY_PCR.49, CORE_DISPLAY_PCR.50 → CORE_DISPLAY_PCR_49_50.java → test_core_display_pcr_49_50.py
- CORE.DISPLAY.PCR.209 → CORE_DISPLAY_PCR_209.java → test_core_display_pcr_209.py

## Decisions

- Preserve the prior bulk mode as a constrained compatibility profile. Do not apply its no-runtime restriction to the synthetic framework benchmark.
- Correct the observation that Python lacks overriding: it supports overriding. Inspect signatures for actual overload problems.
- Preserve existing hardcoded customer data. Do not reuse a closest row when an exact TestCaseID is missing.
- A behaviorally different existing helper is a blocker, not an accepted equivalent.
- XPath syntax support is not semantic DOM validation. Actual source/DOM checks remain blocked.
- Python reporting uses pytest-html and allure-pytest; Node Playwright HTML reporting is not assumed.
- Shared mapping files must retain every manual ID. Manual ID totals are not executable invocation counts.

## Missing inputs

Source Java and build/test metadata; target framework and canonical reference; Display_PCR.xlsx manual actions/expected results; test data; safe application URL/auth; required browser matrix.
